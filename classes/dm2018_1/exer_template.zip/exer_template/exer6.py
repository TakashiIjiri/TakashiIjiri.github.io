# -*- coding: utf-8 -*-
# exer6.py
# 画像の赤と青チャンネルを交換する

import numpy as np
import sys
import cv2

#load image
fname_in  = sys.argv[1]
fname_out = sys.argv[2]

img = cv2.imread(fname_in)

H   = img.shape[0]
W   = img.shape[1]



for y in range(H) :
    for x in  range(W) :
        #ここを編集

        img[y,x,1] = 0　#このコードでは緑チャンネルをゼロにしています

        #発展:1行でも書けます
        #発展:for文を使わずスライスを利用しても良いです



#save image
cv2.imwrite(fname_out, img )
