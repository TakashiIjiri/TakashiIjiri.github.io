# -*- coding: utf-8 -*-
# exer4.pyの雛形
# 画像をグレースケール化して，セーブする
import numpy as np
import sys
import cv2


#load image
fname_in  = sys.argv[1]
fname_out = sys.argv[2]
img = np.float32( cv2.imread(fname_in) )

#grayscale画像の作成
H   = img.shape[0]
W   = img.shape[1]
img_gray = np.zeros((H,W), dtype=np.float32) #型はnp.float32


#!!ここを編集!!
#以下のコードでは，画像のr値をimg_grayに代入している
for y in range(H) :
    for x in range(W) :
        img_gray[y,x] = img[y,x,0]




#save image
cv2.imwrite(fname_out, np.uint8(img_gray) )

#解説 : uint8だと255を超えたらオーバーフローするので，画像を一度float値にしています
#解説 : float型のnumpy arrayは画像としてセーブできないのでセーブ時にuint8二変換しなおしています．
# cv2.imwrite は，カラー（3channel）とグレースケール(1channel)の配列に対して利用可能です．
