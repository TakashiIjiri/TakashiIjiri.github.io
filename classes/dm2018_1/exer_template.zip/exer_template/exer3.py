# -*- coding: utf-8 -*-
# exer3.pyの雛形
import sys

#ファイル名をコマンドライン引数から受け取る
file_in  = sys.argv[1]
file_out = sys.argv[2]

# ファイルの読み込み（今回は書いておきます）
data_array = [] #dataを入れる配列
f = open(file_in, "r")
lines = f.readlines()
for line in lines:
    data_array.append( int(line) )


# !!ここを編集!!
# data_arrayの最大値最小値を取得
# ヒントpythonの機能を使っても良いですし，for文を使っても良いです
maxV = 0
minV = 0




#fileにmaxVとminVを書き出す（今回は書いておきます）
f = open(file_out, "w")
f.write( str(maxV) + " " + str(minV) )
f.close()

print(maxV, minV)
