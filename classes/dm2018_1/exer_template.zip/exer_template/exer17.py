# -*- coding: utf-8 -*-
# exer17.py
#
import cv2


#!!ここを編集!!
#ヒント: どのようなアルゴリズムを使っても良いですし、OpenCVの関数を使っても良いです
