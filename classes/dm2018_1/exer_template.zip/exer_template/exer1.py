# -*- coding: utf-8 -*-
# exer1.pyの雛形

import sys

#二つの数値をコマンドライン引数から受け取る
a = int(sys.argv[1])
b = int(sys.argv[2])


# !!以下を編集!!
#a*b回だけ 　hello, world  と表示する
#ヒント: 余計なものは表示しないようにしてください(下のprint(a,b)は消してください)
print(a, b)
