# -*- coding: utf-8 -*-
# exer10.py
# 5x5メディアンフィルタを実装する
import numpy as np
import sys
import cv2

fname_in  = sys.argv[1]
fname_out = sys.argv[2]

#画像をロード, グレースケール化, float型へ変換
img = cv2.imread(fname_in)
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

#出力画像を準備(グレースケール，float型)
img_out = np.zeros_like( img )



#!!以下を編集!!
#ヒント：これまでのフィルタと同様にfor文で2重ループするところから始めるとよい
#ヒント : 周囲2画素分にはアクセスしないこと
#ヒント : np.median() という関数を利用するのをお勧めします



#float型からuint8型に変換し、書き出し
cv2.imwrite(fname_out, img_out )
