# -*- coding: utf-8 -*-
# exer21.py
# テクスチャ合成
#
#  $python exer21.py sample.png R out.png
#
