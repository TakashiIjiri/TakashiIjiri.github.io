# -*- coding: utf-8 -*-
# exer1.py
# 1枚の画像を輝度値画像に変換し平均輝度値をテキストに出力する
#
#  $python exer1.py img.png out.txt
#
#  img.png : 入力画像1のファイル名
#  out.txt : 平均輝度値を書き込むファイル名

import numpy as np
import sys
import cv2

#load image
fname_in  = sys.argv[1]
fname_out = sys.argv[2]
img = cv2.imread(fname_in)

#輝度画像へ変換（平均値がオーバーフローしないようfloat64にキャスト）
img = np.float64( cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) )

#---------------------------

#ここを編集して，mean_valueを計算
#最初の問題なのでとても簡単です．for文を使ったり、numpyを使ったり色々やってみてください
mean_value = 0

#---------------------------


#値をファイルに入れて出力
f = open(fname_out, "w")
f.write( str(mean_value) )
f.close()
