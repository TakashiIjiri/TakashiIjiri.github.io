# -*- coding: utf-8 -*-
#  exer13.py
#  入力画像にCannyフィルタを適用しエッジ画像化せよ
#
# $python  exer13.py   fname_in.png  fname_out.png
#
#  fname_in.png  : 入力画像のファイル名
#  fname_out.png : 出力画像(エッジ画像)のファイル名

import numpy as np
import sys
import cv2

fname_in  = sys.argv[1]
fname_out = sys.argv[2]

#画像を読み込み輝度画像へ変換
img = cv2.imread(fname_in)
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

#------------------------------------------------

#ここを編集しcanny filter計算と画像の書き出を行う
#ヒント：2行で書ける, 課題の仕様に沿ったパラメータの指定を忘れずに

#------------------------------------------------
