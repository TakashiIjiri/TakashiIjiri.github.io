# exer22.py
# MNISTのトレーニングデータ と ラベル値の不明な画像3枚 を読み込み、
# SVMによりラベルの値を推定せよ。
#
# python exer22.py k img1.png img2.png img3.png
# k          : kNNの近傍数
# img1.png   : 推定対象の画像ファイル名1
# img2.png   : 推定対象の画像ファイル名2
# img3.png   : 推定対象の画像ファイル名3
# output.txt : 推定結果を出力するファイル

import numpy as np
import sys
import cv2
import gzip
from sklearn import svm

img1      = np.uint8( cv2.imread( sys.argv[1], 0 ))
img2      = np.uint8( cv2.imread( sys.argv[2], 0 ))
img3      = np.uint8( cv2.imread( sys.argv[3], 0 ))

#-----------------------
# ここを編集（MNISTのLoad部分には前課題を利用してください）

#----------------------
