# exer19.py
#  画像内の種の個数を数え標準出⼒に書き出すプログラムを作成せよ
#
#  $python exer19.py img.png
#  img.png  : 入力画像のファイル名

import numpy as np
import sys
import cv2

#load image
fname_in  = sys.argv[1]
img = cv2.imread(fname_in)


#TODOここを編集

#自由にアルゴリズムを考えてください
#出力が正しければアルゴリズムが洗練されてなくてもOK
#標準出力には種の数以外のものを書き出さないでください
