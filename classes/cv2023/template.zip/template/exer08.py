# exer08.py 2023cv
# ランダムに選択された30%の画素が黒く塗りつぶされた劣化画像を入力とし、なるべく元画像に近い画像を復元せよ。
#
# > python exer08.py input.png output.png
# input.png  : 入力画像ファイル名
# output.png : 出力画像ファイル名
#

# 下記を編集（全体を書いてみてください）
