#  exer17.py
#  MNISTのトレーニングデータを読みこみ，n番目の画像を出力する．
# 出力画像のファイル名は，[n]_[label].pngとする
#
#  $python  exer17.py  n
#
#  n  : データの番号[0,5999]
#

import numpy as np
import sys
import cv2
import gzip

def open_mnist_image(fname) :
    f = gzip.open(fname, 'rb')
    data = np.frombuffer( f.read(), np.uint8, offset=16)
    f.close()
    return data.reshape((-1, 784)) # (n, 784)の行列に整形, nは自動で決定

def open_mnist_label(fname):
    f = gzip.open(fname, 'rb')
    data = np.frombuffer( f.read(), np.uint8, offset=8 )
    f.close()
    return data.flatten() # (n, 1)の行列に整形, nは自動で決定


#LOAD MNIST
fname_train_img   = "../mnist/train-images-idx3-ubyte.gz"
fname_train_label = "../mnist/train-labels-idx1-ubyte.gz"
x_train = open_mnist_image( fname_train_img   )
t_train = open_mnist_label( fname_train_label )


#-------------------------------------------------------------------
# ここを編集

# この課題はとても簡単なので、x_trainを100個程度書き出してみたり、
# t_trainの中身をチェックしてみたり、自分でいろいろとやってみてください）
# 卒論でパターン認識をやる人にとって, MNISTは練習によく使うデータセットなので
# 今扱いに慣れておくことをお勧めします
#ヒント : 728次元ベクトルを，28x28行列に変換するためには, 『numpy reshape』で検索を！
#ヒント : mnistフォルダの場所は，exer17.pyが入ったフォルダのひとつ上のフォルダです．お間違いなく．


#-------------------------------------------------------------------
