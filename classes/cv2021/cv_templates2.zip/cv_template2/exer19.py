#  exer19.py
#  MNISTのトレーニングデータを読み，さらにラベル値の不明な画像を一枚読み込み，
#  SVMによりラベルの値を推定せよ, 推定結果はoutput.txtへ
#
#  $python  exer19.py  img1.png  img2.png  img3.png  output.txt
#
#  img1.png img2.png img3.png : 入力画像のファイル名(推測対象)
#  output.txt                 : 推定結果を出力するファイル
#

import numpy as np
import sys
import cv2
import gzip
from sklearn import svm


img1      = np.uint8( cv2.imread( sys.argv[1], 0 ))
img2      = np.uint8( cv2.imread( sys.argv[2], 0 ))
img3      = np.uint8( cv2.imread( sys.argv[3], 0 ))
fname_out = sys.argv[4]

#-----------------------

# TODO ここを編集（MNISTLoad部分は exer17.pyを利用してください）
# ヒント : 画像データは2次元配列であるが，v = img.flatten() で
#         1次元配列へ変換しなおせる


#----------------------
