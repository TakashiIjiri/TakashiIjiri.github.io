#  exer18.py
#  MNISTのトレーニングデータを読み，さらにラベル値の不明な画像を3枚読み込み，
#  kNNによりラベルの値を推定せよ, 推定結果はoutput.txtへ
#
#  $python  exer18.py  k  img1.png  img2.png  img3.png  output.txt
#
#  k          : kNNの近傍数
#  img1.png img2.png img3.png :  入力画像のファイル名(推測対象)
#  output.txt : 推定結果を出力するファイル
#

import numpy as np
import sys
import cv2
import gzip
from sklearn.neighbors import KNeighborsClassifier

k         = int(sys.argv[1])
img1      = np.uint8( cv2.imread( sys.argv[2], 0 ))
img2      = np.uint8( cv2.imread( sys.argv[3], 0 ))
img3      = np.uint8( cv2.imread( sys.argv[4], 0 ))
fname_out = sys.argv[5]



#-----------------------
# TODO ここを編集（MNISTLoad部分は exer17.pyを利用してください）
# ヒント : 画像データは2次元配列であるが，v = img.flatten() で
#         1次元配列へ変換しなおせる

# todo1 mnist読み込み関数をコピーしてくる

# todo2 mnistを読み込む

# todo3 knnを利用してimg1 img2 img3のラベルを推定


#-----------------------


#-------------------------------------------------------------------------------
# 以下，KNeighborsClassifierの使い方の説明（提出時には削除を）

# 例として、特徴ベクトル2次元，クラス数３（ラベルは｛0,1,2｝），各クラス2点ずつのトレーニングデータを考える
# label 0 : (0,0), (1,0)　の2点
# label 1 : (2,1), (2,2)　の2点
# label 2 : (0,2), (0,1)　の2点
x_train = np.array([[0,0], [1,0],
                    [2,1], [2,2],
                    [0,2], [0,1], ])
t_train = np.array([0,0, 1,1, 2,2])

# k = 1 として kNN識別機のインスタンスを作成
knn = KNeighborsClassifier(n_neighbors = 1)

# kNN識別機にトレーニングデータを渡す
knn.fit( x_train, t_train )

# 例として, 2点, (0.5,0.5), (0.0,0.5)のラベル推定を行ってみる
# ラベル推定をしたい特徴ベクトルを2次元行列にまとめてpredict関数へ送る
estim = knn.predict( [[0.5,0.5],[0.0,0.5] ] )

print ( estim )
#------------------------------------------------------------------------------
