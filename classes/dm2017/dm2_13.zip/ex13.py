# ex12.py
import numpy as np
import cv2

#load image and comvert to float
img1 = cv2.imread("img1.png").astype(np.float)
img2 = cv2.imread("img2.png").astype(np.float)
img3 = cv2.imread("img3.png").astype(np.float)

#以下を編集し平均画像を生成せよ
img  = np.zeros_like(img1);  
        
#display img
cv2.imshow("img1", np.uint8( img1) )
cv2.imshow("img2", np.uint8( img2) )
cv2.imshow("img3", np.uint8( img3) )
cv2.imshow("img ", np.uint8( img) )
cv2.waitKey()