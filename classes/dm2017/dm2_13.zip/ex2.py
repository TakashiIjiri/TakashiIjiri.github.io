# ex2.py

#int
a = 1234 
print(a, type(a),id(a))

#float
a = 1.234
print(a, type(a),id(a))
a = 1.2345
print(a, type(a),id(a))
a = 1
print(a, type(a),id(a))

#bool
a = True 
print(a, type(a),id(a))

#string
a = "hello, world"
print(a, type(a),id(a))

#型変換例: float->int, string->int, int->float
a = int(16.2)
a = int('16')
a = float(16)