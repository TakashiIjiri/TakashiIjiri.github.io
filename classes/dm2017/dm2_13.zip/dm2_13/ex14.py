# ex14.py
import numpy as np
import cv2

#load grayscale image
image_gray = cv2.imread("imgFace.jpg",0)

#
face_cascade = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
facerect = face_cascade.detectMultiScale( image_gray, scaleFactor=1.1, minNeighbors=1, minSize=(100, 100), maxSize=(300,300))

for rect in facerect:
    print(rect)
    cv2.rectangle(image_gray, tuple(rect[0:2]),tuple(rect[0:2]+rect[2:4]), (255,255,255), thickness=4)

cv2.imwrite("res.png", image_gray)
cv2.imshow("test", image_gray)
cv2.waitKey()

#参考1 http://workpiles.com/2015/04/opencv-detectmultiscale-scalefactor/
#参考2 http://workpiles.com/2015/04/opencv-detectmultiscale-minneighbors/
