# ex5.py
import numpy as np

A    = np.array([1,2,3,4,5,6,7,8])
mean = np.mean( A )
sum  = np.sum ( A )
vari = np.var ( A )
print( mean, sum, vari)

A = A-mean
A = A**2
print( np.sum(A)/A.shape[0]);