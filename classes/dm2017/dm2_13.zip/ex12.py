# ex12.py
import numpy as np
import cv2

#load image as grayscale and float
img = cv2.imread("img.png",0).astype(np.float)
img_x = np.zeros_like( img )
img_y = np.zeros_like( img )

for y in range(1, img.shape[0]-1) : 
    for x in range(1, img.shape[1]-1) :        
        dx = 128 #ここを編集
        dy = 128 #ここを編集

        if( dx < 0   ) : dx *= -1
        if( dx > 255 ) : dx  = 255
        if( dy < 0   ) : dy *= -1
        if( dy > 255 ) : dy  = 255
        img_x[y,x] = dx
        img_y[y,x] = dy
           
cv2.imshow( "a", img  .astype(np.uint8) )
cv2.imshow( "b", img_x.astype(np.uint8) )
cv2.imshow( "c", img_y.astype(np.uint8) )
cv2.waitKey()
