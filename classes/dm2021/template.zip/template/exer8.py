# 画像の赤と緑チャンネルを交換する
import numpy as np
import sys
import cv2

#load image
fname_in  = sys.argv[1]
fname_out = sys.argv[2]

img    = cv2.imread(fname_in)
height = img.shape[0]
width  = img.shape[1]


#!!ここを編集
#ヒント: for文で全画素をまわって r-channelとg-channelを入れ替える
#ヒント: グレースケール化の課題が参考になる


#save image
cv2.imwrite(fname_out, img )
