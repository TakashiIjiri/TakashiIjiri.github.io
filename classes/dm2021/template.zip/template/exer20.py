import numpy as np
import sys
import cv2
import math

fname1 = sys.argv[1] #img
fname2 = sys.argv[2] #kernel


#Kernelの読み込み (総和を1にしつつ fftshiftする)
kernel = cv2.cvtColor( cv2.imread(fname2), cv2.COLOR_RGB2GRAY)
kernel = np.float32(kernel / np.sum(kernel))
kernel = np.fft.fftshift(kernel)
