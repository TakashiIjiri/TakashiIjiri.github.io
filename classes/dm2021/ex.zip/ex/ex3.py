# -*- coding: utf-8 -*-
# ex3.py

import sys
a1 = sys.argv[1]
a2 = sys.argv[2]
a3 = sys.argv[3]
print(a1, a2, a3)
