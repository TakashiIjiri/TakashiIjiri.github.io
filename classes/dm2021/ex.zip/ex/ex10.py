# ex10.py
import numpy as np
import cv2

#load image
img = cv2.imread("img.png")
print( img.shape, type(img), img.dtype )

#save image
cv2.imwrite("img_save.png", img);

#display img
cv2.imshow("show image", img)
cv2.waitKey()
