
// TImageProcessView.cpp : CTImageProcessView �N���X�̎���
//

#include "stdafx.h"
// SHARED_HANDLERS �́A�v���r���[�A�T���l�C���A����ь����t�B���^�[ �n���h���[���������Ă��� ATL �v���W�F�N�g�Œ�`�ł��A
// ���̃v���W�F�N�g�Ƃ̃h�L�������g �R�[�h�̋��L���\�ɂ��܂��B
#ifndef SHARED_HANDLERS
#include "TImageProcess.h"
#endif

#include "TImageProcessDoc.h"
#include "TImageProcessView.h"
#include "TCore.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#endif






// CTImageProcessView

IMPLEMENT_DYNCREATE(CTImageProcessView, CView)

BEGIN_MESSAGE_MAP(CTImageProcessView, CView)
	// �W������R�}���h
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MBUTTONDBLCLK()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_RBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CTImageProcessView �R���X�g���N�V����/�f�X�g���N�V����

CTImageProcessView::CTImageProcessView()
{
	m_bLButton     = m_bRButton = m_bMButton    = false;
	m_bTranslating = m_bZooming = m_bDrawStroke = false;

	m_transX = -7   ;
	m_transY = -3.5 ;
	m_zoom   = 1.1 ;
}

CTImageProcessView::~CTImageProcessView()
{

}

BOOL CTImageProcessView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}


BOOL CTImageProcessView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// ����̈������
	return DoPreparePrinting(pInfo);
}

void CTImageProcessView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CTImageProcessView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}


// CTImageProcessView �f�f

#ifdef _DEBUG
void CTImageProcessView::AssertValid() const
{
	CView::AssertValid();
}

void CTImageProcessView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTImageProcessDoc* CTImageProcessView::GetDocument() const // �f�o�b�O�ȊO�̃o�[�W�����̓C�����C���ł��B
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTImageProcessDoc)));
	return (CTImageProcessDoc*)m_pDocument;
}
#endif //_DEBUG


// CTImageProcessView ���b�Z�[�W �n���h���[


int CTImageProcessView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1) return -1;
	TCore::getInst()->m_ogl.OnCreate( this );
	return 0;
}
void CTImageProcessView::OnDestroy()
{
	CView::OnDestroy();
	TCore::getInst()->m_ogl.OnDestroy();
}

void CTImageProcessView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);


	TCore::getInst()->m_ogl.OnSize(cx,cy);
}


BOOL CTImageProcessView::OnEraseBkgnd(CDC* pDC)
{
	return true; // return CView::OnEraseBkgnd(pDC);
}

void CTImageProcessView::OnDraw(CDC* /*pDC*/)
{
	CTImageProcessDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc) return;


	const double rectW = TCore::getInst()->m_imgRectW * m_zoom;
	const double rectH = TCore::getInst()->m_imgRectH * m_zoom;
	TCore::getInst()->m_ogl.OnDraw_Begin( rectW, -m_transX, -m_transY);

	glPushMatrix();

	if( m_bDrawStroke )
	{
		glLineWidth( 3 ) ;
		glColor3d( 1,1,0);
		glBegin( GL_LINE_STRIP );
		for( int i=0; i < (int)m_contour.size(); ++i) glVertex3d( m_contour[i].data[0], m_contour[i].data[1], 0.1);
		if( !m_contour.empty() ) glVertex3d( m_contour[0].data[0], m_contour[0].data[1], 0.1);
		glEnd();
	}


	TCore::getInst()->drawScene();

	glPopMatrix();
	TCore::getInst()->m_ogl.OnDraw_End  ();


}




void CTImageProcessView::convertCursorPosToWorldPos( const CPoint &point, double &x, double &y)
{
	TCore::getInst()->m_ogl.GetCursorPos( point.x, point.y, x,y);
}








void CTImageProcessView::OnLButtonDblClk(UINT nFlags, CPoint point){}
void CTImageProcessView::OnMButtonDblClk(UINT nFlags, CPoint point){}
void CTImageProcessView::OnRButtonDblClk(UINT nFlags, CPoint point){}






void CTImageProcessView::OnLButtonDown(UINT nFlags, CPoint point){
	m_bLButton = true;
	double x, y; convertCursorPosToWorldPos( point, x, y);
	
	if( 0 <= x && x <= TCore::getInst()->m_imgRectW && 
		0 <= y && y <= TCore::getInst()->m_imgRectH ) 
	{
		m_bDrawStroke = true;
		m_contour.clear();
		m_contour.push_back( TVector3(x,y,0) );
	}
	else
		m_bTranslating = true;

	SetCapture();
	m_prePoint = point;
}


void CTImageProcessView::OnLButtonUp(UINT nFlags, CPoint point){
	ReleaseCapture();

	if( m_bDrawStroke && m_contour.size () > 4 ) TCore::getInst()->setInitialActiveContour( m_contour );

	m_bLButton = m_bTranslating = m_bDrawStroke = false;
	RedrawWindow();
}

void CTImageProcessView::OnMButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	m_bMButton = m_bZooming = true;
	m_prePoint = point;
}
void CTImageProcessView::OnMButtonUp(UINT nFlags, CPoint point)
{
	ReleaseCapture();
	m_bMButton = m_bZooming = false;
	this->RedrawWindow();
}

void CTImageProcessView::OnRButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	m_bRButton = m_bTranslating = true;
	m_prePoint = point;
}
void CTImageProcessView::OnRButtonUp(UINT nFlags, CPoint point)
{
	ReleaseCapture();
	m_bRButton = m_bTranslating = false;
	RedrawWindow();
}





void CTImageProcessView::OnMouseMove(UINT nFlags, CPoint point)
{
	if( m_bDrawStroke  )
	{
		double x, y; convertCursorPosToWorldPos( point, x, y);
	
		if( 0 <= x && x <= TCore::getInst()->m_imgRectW && 0 <= y && y <= TCore::getInst()->m_imgRectH ) {
			m_contour.push_back( TVector3(x,y,0) );
		}
	}
	if( m_bTranslating ) 
	{
		double x1,y1;  TCore::getInst()->m_ogl.GetCursorPos( m_prePoint.x, m_prePoint.y, x1, y1);
		double x2,y2;  TCore::getInst()->m_ogl.GetCursorPos(      point.x,      point.y, x2, y2);
		m_transX += x2 - x1;
		m_transY += y2 - y1;
		m_prePoint = point;
	}

	if( m_bZooming )
	{
		m_zoom *= 1 - 0.001*( point.y - m_prePoint.y);
		m_prePoint = point;
	}

	if( m_bLButton || m_bRButton || m_bMButton ) this->RedrawWindow();
}


BOOL CTImageProcessView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt){
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}






void CTImageProcessView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags){
fprintf( stderr, "%d", nChar );

	if( nChar == 37 ) TCore::getInst()->m_ROT_Z += 2; //��
	if( nChar == 38 ) TCore::getInst()->m_ROT_X += 2; //��
	if( nChar == 39 ) TCore::getInst()->m_ROT_Z -= 2; //�E
	if( nChar == 40 ) TCore::getInst()->m_ROT_X -= 2; //��
	RedrawWindow();
}




