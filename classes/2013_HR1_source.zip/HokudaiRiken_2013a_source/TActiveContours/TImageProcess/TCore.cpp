#include "StdAfx.h"
#include "TCore.h"


#ifndef MIN3
#define MIN3(  a,b,c)	((a)<(b)?((a)<(c)?(a):(c)):((b)<(c)?(b):(c)))
#define MAX3(  a,b,c)	((a)>(b)?((a)>(c)?(a):(c)):((b)>(c)?(b):(c)))
#define MIN3ID(a,b,c)	((a)<(b)?((a)<(c)?(0):(2)):((b)<(c)?(1):(2)))
#define MAX3ID(a,b,c)	((a)>(b)?((a)>(c)?(0):(2)):((b)>(c)?(1):(2)))
template <class T> T   max3  (T a,T b,T c){return MAX3(  a,b,c);}
template <class T> int max3id(T a,T b,T c){return MAX3ID(a,b,c);}
template <class T> T   min3  (T a,T b,T c){return MIN3(  a,b,c);}
template <class T> int min3id(T a,T b,T c){return MIN3ID(a,b,c);}
#endif


#ifdef _DEBUG
#define new DEBUG_NEW
#endif





//byte *sobelX, byte sobelY should be allocated before
//color [0,255]-->[0,1]
static void t_sobel( const byte *rgba, const int W, const int H, double *sobelX, double *sobelY)
{
	double filterX[3][3]={	{-1,  0,  1}, {-2,  0,  2}, {-1,  0,  1}};
	double filterY[3][3]={  {-1, -2, -1}, { 0,  0,  0}, { 1,  2,  1}};

	memset( sobelX, 0, sizeof( double ) * W*H );
	memset( sobelY, 0, sizeof( double ) * W*H );

	for(int y = 1; y < H-1 ; y++)
	for(int x = 1; x < W-1 ; x++)
	{
		int idx = x + y * W; 
		double vx = 0, vy = 0 ;		
		for( int wy = -1; wy < 2; ++wy)
		for( int wx = -1; wx < 2; ++wx)
		{
			int pixId = 4*( idx + wx + wy * W );
			double pixVal;
			if( x + wx < 0 || x + wx > W-1 || y + wy < 0 || y + wy > H-1 ) pixVal = 0;
			else pixVal	= (rgba[ pixId + 0] + rgba[ pixId + 1] + rgba[ pixId + 2] ) * 0.33333 / 255.0;
			vx += filterX[wy+1][wx+1] * pixVal;
			vy += filterY[wy+1][wx+1] * pixVal;
		}
		sobelX[ idx ] = fabs( vx ) ;
		sobelY[ idx ] = fabs( vy ) ;
	}
}





TCore::~TCore(void){
	if( m_gradMag != 0){
		delete[] m_gradMag;
		delete[] m_distField;
	}
}

TCore::TCore(void)
{
	m_gradMag = 0;
	m_distField = 0;
	m_ROT_X = -70;
	m_ROT_Z =  20;

	//load image
	CString         filter("bmp Files (*.bmp;*.bmp)|*.bmp; *.bmp||");
	CFileDialog     selDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, filter);
	bool inverted;
	if (selDlg.DoModal() == IDOK) m_imgOrig.allocateFromFile( selDlg.GetPathName(), inverted, &m_ogl );
	else exit(1);
	if( inverted ) m_imgOrig.flipImageInY();
	                                           
	m_imgDisp  .allocateImage( m_imgOrig, 0 ); 
	m_imgOrig  .m_DoInterpolation = false;
	m_imgDisp  .m_DoInterpolation = false;


	const int W = m_imgOrig.m_width ;
	const int H = m_imgOrig.m_height;
	const int WH = W*H;
	m_imgRectW = 7.0;
	m_imgRectH = 7.0 / (double) W * H;


	m_dlg.Create( IDD_DIALOG_IMGPRC );
	m_dlg.ShowWindow( SW_SHOW );


	//���z���x���v�Z���Ă���
	//compute watershed segmentation (1)sobel, (2)watershed, (3)fill watershed pixel
	for( int i=0; i < 15; ++i) m_imgDisp.gaussianFilter33();
	double *sobelX   = new double[ WH ];
	double *sobelY   = new double[ WH ];
	m_gradMag        = new double[ WH ];

	t_sobel( m_imgDisp.m_RGBA, W, H, sobelX, sobelY);
	for( int i=0; i<WH; ++i) m_gradMag[i] = sqrt( sobelX[i]*sobelX[i] + sobelY[i]*sobelY[i]);

	delete[] sobelX;
	delete[] sobelY;


	m_distField = new double[ WH ];
}













static void drawHeightField( const int W, const int H, const double PIX_R, const double *func)
{

	float shin[1] = {32.0f};
	float spec[4] = {1,1,1,1};
	float diff[4] = {0.3f, 0.8f, 0.1f,0.5f};
	float ambi[4] = {0.1f, 0.2f, 0.2f,0.5f};
	glEnable( GL_LIGHTING );
	glEnable( GL_LIGHT0 );
	glEnable( GL_LIGHT1 );
	glEnable( GL_LIGHT2 );
	glMaterialfv( GL_FRONT_AND_BACK, GL_SHININESS, shin );
	glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR,  spec );
	glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE,   diff );
	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT,   ambi );

	TVector3 p0,p1,p2,p3, n;
	glBegin( GL_QUADS );
	for( int y = 1; y < H; ++y)
	for( int x = 1; x < W; ++x)
	{
		const int idx = x + W*y;
		p0.Set( (x-1) * PIX_R, (y-1) * PIX_R, func[ idx -1 -W] );
		p1.Set( (x  ) * PIX_R, (y-1) * PIX_R, func[ idx    -W] );
		p2.Set( (x  ) * PIX_R, (y  ) * PIX_R, func[ idx      ] );
		p3.Set( (x-1) * PIX_R, (y  ) * PIX_R, func[ idx -1   ] );

		n[0] = (p1[1] - p0[1]) * (p2[2] - p0[2])   -   (p1[2] - p0[2]) * (p2[1] - p0[1]);
		n[1] = (p1[2] - p0[2]) * (p2[0] - p0[0])   -   (p1[0] - p0[0]) * (p2[2] - p0[2]);
		n[2] = (p1[0] - p0[0]) * (p2[1] - p0[1])   -   (p1[1] - p0[1]) * (p2[0] - p0[0]);	
		n.Normalize_Self();


		glNormal3dv( n.data );
		glVertex3dv( p0.data );
		glVertex3dv( p1.data );
		glVertex3dv( p2.data );
		glVertex3dv( p3.data );
	}
	glEnd();

}



static void drawImage( const double rectW, const double rectH, TOGL2DImage &img)
{
	glDisable( GL_LIGHTING  );
	glDisable( GL_CULL_FACE );
	glColor3d( 1,1,1        );
	glEnable( GL_TEXTURE_2D );
	img.bind(0);
	glBegin  ( GL_QUADS     );
	glTexCoord2d(0,0); glVertex3d(     0,    0, 0 );
	glTexCoord2d(1,0); glVertex3d( rectW,    0, 0 );
	glTexCoord2d(1,1); glVertex3d( rectW,rectH, 0 );
	glTexCoord2d(0,1); glVertex3d(     0,rectH, 0 );
	glEnd( );
	glDisable( GL_TEXTURE_2D );
}


static void drawRect(const double rW, const double rH, const double r, const double g, const double b, const double width)
{
	glColor3d( r,g,b );
	glLineWidth( (float)width );
	glBegin( GL_LINE_STRIP );
		glVertex3d( 0, 0, 0); glVertex3d( rW,0,0); glVertex3d( rW,rH,0);
		glVertex3d( 0,rH, 0); glVertex3d( 0 ,0,0);
	glEnd();

}


void TCore::drawScene()
{
	const int    W  = m_imgOrig.m_width, H = m_imgOrig.m_height ;	
	const double rW = m_imgRectW       , rH = m_imgRectH        ;	
	
	glDisable( GL_LIGHTING );

	drawRect( rW, rH, 1,1,0, 8);

	glPushMatrix();
		drawImage( rW, rH, m_imgOrig   ); glTranslated(   rW + 0.5, 0, 0); 
		drawImage( rW, rH, m_imgDisp   );
	glPopMatrix();


	glTranslated(0,0,0.1 );
		glLineWidth( 6 );
		glColor3d( 0, 1, 1); 
		glBegin( GL_LINE_STRIP );
		for( int i=0; i<(int) m_contour.size(); ++i) glVertex3dv( m_contour[i].data );
		if( !m_contour.empty() ) glVertex3dv( m_contour.front().data );
		glEnd();

		glTranslated(0,0,0.1 );

			glColor3d( 1,0,0 );
			glPointSize( 8 );
			glBegin( GL_POINTS );
			for( int i=0; i<(int) m_contour.size(); ++i) glVertex3dv( m_contour[i].data );	
			glEnd();
	
			//draw boundary
			glLineWidth( 6 );

			glColor3d( 0,1,1);
			glBegin( GL_LINES );
			for( int i=0, s=(int)m_boundLines.size(); i<s; ++i){ 
				glVertex3d( m_boundLines[i].x1, m_boundLines[i].y1, 0.1 ); 
				glVertex3d( m_boundLines[i].x2, m_boundLines[i].y2, 0.1 ); 
			}
			glEnd();


		glTranslated(0,0, -0.1 );
	glTranslated(0,0, -0.1 );


	glPushMatrix();
		glTranslated( -rW * 1.4,  0.5 * rH,0 );
		glTranslated(  rW * 0.5,  0       ,0 );
		glRotated( m_ROT_X, 1,0,0);
		glRotated( m_ROT_Z, 0,0,1);
		glTranslated( -rW * 0.5, -0.5 * rH,0 );

		drawRect( rW,rH,1,1,0, 8);

		drawHeightField(W,H, m_imgRectW / W, m_distField );
		//draw boundary
		glDisable( GL_LIGHTING);
		glLineWidth( 4 );

		glColor3d( 0,1,1);
		glBegin( GL_LINES );
		for( int i=0, s=(int)m_boundLines.size(); i<s; ++i){ 
			glVertex3d( m_boundLines[i].x1, m_boundLines[i].y1, 0.1 ); 
			glVertex3d( m_boundLines[i].x2, m_boundLines[i].y2, 0.1 ); 
		}
		glEnd();

	glPopMatrix();

}



























inline double t_distance_sq(const TVector3 &v1, const TVector3 &v2){
	return  (v1.data[0] - v2.data[0]) * (v1.data[0] - v2.data[0]) + 
		    (v1.data[1] - v2.data[1]) * (v1.data[1] - v2.data[1]) + 
		    (v1.data[2] - v2.data[2]) * (v1.data[2] - v2.data[2]) ;		         
}

inline double t_distance   (const TVector3 &v1, const TVector3 &v2){ return sqrt( t_distance_sq  (v1, v2) ); }

inline double t_stroke_Length(const vector<TVector3> &str, bool bClosed = false)
{
	double d = 0;
	if( bClosed && str.size() >= 2) d += t_distance( str.back(), str.front() );
	for( int i = 1; i < (int) str.size(); ++i ) d += t_distance( str[i], str[i-1] );
	return d;
}
/*--------------------------------------------------------------------------------
//devide the stroke into "n" section so that they are equaly spaced along itself.
//This method return n+1 points;
//closed Stroke������������B�A���Ă���_���n
--------------------------------------------------------------------------------*/
inline void t_stroke_devideEquals_closed(int n, const vector<TVector3> &stroke ,vector<TVector3> &result)
{
	if( stroke.size() < 2 ) {result.resize( n ); return;}

	double strokeLength = t_stroke_Length( stroke  ) + t_distance(stroke.front(), stroke.back()); 
	double stepD        = strokeLength / (double) n;
	result.clear();
	
	if(stepD == 0){	result.resize(n); return; }


	double distance  = 0;
	result.push_back( stroke[0]);
	TVector3 pivot = stroke[0];

	TVector3 vec, point;
	for( int index = 1, sSize = (int)stroke.size(); index <= sSize;)
	{
		const TVector3 &newP = (index == sSize) ? stroke.front() : stroke[index];
		distance += t_distance( newP, pivot );

		if( distance >= stepD )//���݉z��
		{
			vec.SetSubtract( pivot, newP ); 
			vec.Normalize_Self();
			vec *= (distance - stepD);//���݉z����.;

			point.SetAddition(newP, vec);
			result.push_back(point);
			//����Ɏ��Ɍ����čX�V.index�̓C���N�������g���Ȃ�
			distance = 0;
			pivot.Set(point);
			if( result.size() == n ) return;
		}
		else                   //���݉z���Ă��Ȃ�
		{
			pivot.Set( newP );
			++index;
		}
	}
	
	if(result.size() != n ) { fprintf( stderr, "something wrong error 14231\n");}//�Ō�̗v�f���덷�̊֌W�œ�����ĂȂ��̂ŁA�����
}




void TCore::setInitialActiveContour(vector<TVector3> initContour)
{
	const double PIX_R = m_imgRectW / m_imgOrig.m_width;

	t_stroke_devideEquals_closed( (int)( t_stroke_Length( initContour ) / PIX_R / 6 ), initContour, m_contour );
}



void TCore::runSnakes(const int MAX_ITERATION, double C1, double C2, double C3, int WindowR)
{	
	const int    W     = m_imgOrig.m_width ;  
	const int    H     = m_imgOrig.m_height, WH = W * H;
	const double PIX_R = m_imgRectW / W;


	for( int iteration = 0; iteration < MAX_ITERATION; ++iteration)
	{
		fprintf(stderr, "a" );
		if( iteration % 2 == 0 )
		{
			vector< TVector3 > tmpStr; 
			t_stroke_devideEquals_closed( (int)( t_stroke_Length( m_contour ) / PIX_R / 6 ), m_contour, tmpStr );
			m_contour = tmpStr ;
			m_ogl.RedrawWindow();
		}

		vector< TVector3 > tmpStr( m_contour.size() );

		for( int pi=0, s = (int) m_contour.size(); pi < s; ++pi)
		{
			const TVector3 &preP = (pi== 0 ) ? m_contour.back()  : m_contour[pi-1]; 
			const TVector3 &p    =                                 m_contour[pi  ]; 
			const TVector3 &nexP = (pi==s-1) ? m_contour.front() : m_contour[pi+1]; 
			const int x = (p.data[0] == m_imgRectW ) ? W-1 : (int)( p.data[0] / m_imgRectW * W );
			const int y = (p.data[1] == m_imgRectH ) ? H-1 : (int)( p.data[1] / m_imgRectH * H );

			//9�ߖT��f�Ɉړ������ꍇ�̃G�l���M�[���v�Z���A�ŏ��̒��_�ʒu�Ɉړ�����
			double minEnergy = DBL_MAX;
			TVector3 optimumP, newP;
			for( int xx = -WindowR; xx <= WindowR; ++xx) if( xx + x > 0 && xx + x < W )
			for( int yy = -WindowR; yy <= WindowR; ++yy) if( yy + y > 0 && yy + y < H )
			{
				newP.Set( (x+xx + 0.5) * PIX_R, (y+yy+ 0.5) * PIX_R, 0); 
				double a1 = preP.data[0] + nexP.data[0] - 2 * newP.data[0];
				double a2 = preP.data[1] + nexP.data[1] - 2 * newP.data[1];
				
				double E = 0;
				E +=   C1 * t_distance_sq( newP, preP );   //�����̍�
				E +=   C2 * (a1 * a1 + a2 * a2)        ;   //�ȗ��̍�
				E += - C3 * m_gradMag[ (x+xx) + (y+yy)*W ];//���z���x�̍�

				if( E < minEnergy ) { minEnergy = E; m_contour[pi] = newP; /*optimumP  = newP;*/ }
			}


			tmpStr[ pi ] = optimumP; 
		}
		//m_contour = tmpStr;

	}
}







static double t_distPointToLineSegment( const TVector3 &p , 
								        const TVector3 &lineP0, 
								        const TVector3 &lineP1)
{
	double t =  (p.data[0] - lineP0.data[0]) * (lineP1.data[0] - lineP0.data[0]) + 
		        (p.data[1] - lineP0.data[1]) * (lineP1.data[1] - lineP0.data[1]) + 
				(p.data[2] - lineP0.data[2]) * (lineP1.data[2] - lineP0.data[2]);
	t /= t_distance_sq( lineP1, lineP0 );

	if( t < 0 ) return t_distance( p, lineP0 );
	if( t > 1 ) return t_distance( p, lineP1 );

	double x = lineP0.data[0]  + t * (lineP1.data[0]-lineP0.data[0]) - p.data[0];
	double y = lineP0.data[1]  + t * (lineP1.data[1]-lineP0.data[1]) - p.data[1];
	double z = lineP0.data[2]  + t * (lineP1.data[2]-lineP0.data[2]) - p.data[2];
	return sqrt( x*x + y*y + z*z );
}


void gaussianSmoothing(const int W, const int H, double *field)
{
	double *tmp = new double [ W*H ];
	static double f[3][3]= { {1,2,1}, {2,4,2}, {1,2,1} };
	for( int y=0; y<H; ++y)
	for( int x=0; x<W; ++x)
	{
		double intens= 0, s = 0;
		for( int yy=-1; yy<2; ++yy) if( 0 <= y+yy && y+yy < H)
		for( int xx=-1; xx<2; ++xx) if( 0 <= x+xx && x+xx < W)
		{
			int idx  = x+xx + (y+yy)*W;
			s      += f[yy+1][xx+1];
			intens += f[yy+1][xx+1] * field[ idx ];
		}
		tmp[x+y*W] = intens / s;
	}

	memcpy( field, tmp, sizeof( double ) * W*H);
	delete[] tmp;

}



static void calcDistField( const vector< TVector3 > &contour, const int W, const int H, const double PIX_R, double *distField )
{

	const int N = (int)contour.size();
	TVector3 d1,d2;

	for( int y = 0; y < H; ++y)
	for( int x = 0; x < W; ++x)
	{
		TVector3 P( PIX_R * (x + 0.5), PIX_R * (y + 0.5), 0);
		
		double theta  = 0;
		double dist   = DBL_MAX;
		for( int i=0; i < N; ++i)
		{
			const TVector3 &preP = contour[i==0 ? N-1 : i-1];
			const TVector3 &pivP = contour[              i ];

			d1.SetSubtract( preP, P );
			d2.SetSubtract( pivP, P );
			//����
			double d = t_distPointToLineSegment( P, preP, pivP);
			if( d < dist ) dist = d;
			//�p�x
			if( d1.Length() > 0.0000000001 && d2.Length() > 0.0000000001 )
			{
				double a = min( 0.9999999, (d1 * d2 ) / d1.Length() / d2.Length() ); //1�𒴂����NAN
				double t = acos( a );
				theta += (d1[0] * d2[1] - d1[1] * d2[0] < 0 ) ? -t : t ;
			}
		}

		//fabs( theta )��2PI�t�߂Ȃ����
		distField[ x + y*W ] = ( fabs( theta ) <= 0.5 ) ? - dist : + dist ;
	}
}







static double curvature( const int idx, const int W, const int H, const double *func, const double h)
{

	double fx  = ( func[ idx + 1 ] -  func[ idx     ]                  ) /   h  ;
	double fy  = ( func[ idx + W ] -  func[ idx     ]                  ) /   h  ;
	double fxx = ( func[ idx + 1 ] +  func[ idx - 1 ] - 2* func[ idx ] ) / (h*h);
	double fyy = ( func[ idx + W ] +  func[ idx - W ] - 2* func[ idx ] ) / (h*h);
	double fxy = ( func[ idx + W + 1] +  func[ idx ] -  func[ idx + 1] - func[ idx + W] ) / (h*h);

	double a = sqrt( (fx*fx + fy*fy) * 
		             (fx*fx + fy*fy) * 
					 (fx*fx + fy*fy) );
	if( a < 0.001) return 0;
	return ( fxx*fy*fy - 2*fx*fy*fxy + fyy*fx*fx ) / a;
}





void TCore::runLevelSet(const int MAX_ITERATION, double A)
{
	const int    W     = m_imgOrig.m_width ;  
	const int    H     = m_imgOrig.m_height, WH = W * H;
	const byte  * rgba = m_imgOrig.m_RGBA;
	const double PIX_R = m_imgRectW / W;
	const double dt    = 0.01;


	//�������l-1�ŏ���������
	double * tmpField = new double[WH] ;

	calcDistField( m_contour, W, H, PIX_R, m_distField );


	for( int iteration = 0; iteration < MAX_ITERATION; ++iteration)
	{
		fprintf( stderr, "*****%d****\n", iteration);
		
		for( int y = 1; y < H-1; ++y)
		for( int x = 1; x < W-1; ++x)
		{
			int idx = x + y * W; //Upwind scheme
			double D_px =( m_distField[ idx + 1 ] -  m_distField[ idx    ]) / PIX_R; 
			double D_py =( m_distField[ idx + W ] -  m_distField[ idx    ]) / PIX_R; 
			double D_mx =( m_distField[ idx     ] -  m_distField[ idx - 1]) / PIX_R; 
			double D_my =( m_distField[ idx     ] -  m_distField[ idx - W]) / PIX_R; 
			double Dp = MAX3( D_mx, - D_px , 0 ) * MAX3( D_mx, - D_px , 0 ) + MAX3( D_my, - D_py , 0 ) * MAX3( D_my, - D_py , 0 ) ;
			double Dm = MAX3( D_px, - D_mx , 0 ) * MAX3( D_px, - D_mx , 0 ) + MAX3( D_py, - D_my , 0 ) * MAX3( D_py, - D_my , 0 ) ;
			double DDDp = Dp, DDDm = Dm;
			Dp = sqrt( Dp );
			Dm = sqrt( Dm );

			//����ߐ搶�̃`���[�g���A���̎����@�����s����Ȃ̂Ŏg��Ȃ�
			//double k = curvature( idx, W,H, distField, PIX_R);
			//double F = (A - 0.001*B*k) / (1 + 50 * m_gradMag[ idx ] * m_gradMag[ idx ] );
			double F = 1 / (1 + A * m_gradMag[ idx ] * m_gradMag[ idx ] );

			tmpField[ idx ] = m_distField[idx] - dt * ( max(F,0) * Dp + min(F,0) * Dm ) ; 
		}

		//���͂̓R�s�[���邾��
		for( int x = 1; x < W-1; ++x){ tmpField[ x +   0  *W ] = tmpField[ x    +   1   * W ];  tmpField[ x + (H-1)*W ] = tmpField[ x    + (H-2) * W ]; }
		for( int y = 1; y < H-1; ++y){ tmpField[ 0     + y*W ] = tmpField[ 1    +   y   * W ];  tmpField[ (W-1) + y*W ] = tmpField[(W-2) +   y   * W ]; }
		tmpField[ 0            ] = tmpField[ 1            ];
		tmpField[ W-1          ] = tmpField[ W-2          ];
		tmpField[ 0   + (H-1)*W] = tmpField[  1  + (H-1)*W];
		tmpField[(W-1)+ (H-1)*W] = tmpField[(W-2)+ (H-1)*W];

		memcpy(m_distField, tmpField, sizeof( double ) * WH );



		if( true )//Visualization
		{
			m_boundLines.clear(); 
			for( int y=0; y<H-1; ++y )
			for( int x=0; x<W-1; ++x ){
				int i = x + y * W;
				if( m_distField[i] * m_distField[i+1] < 0 ) m_boundLines.push_back( TLineSegm( (x+1)*PIX_R, (x+1)*PIX_R,  y   *PIX_R, (y+1)*PIX_R) );
				if( m_distField[i] * m_distField[i+W] < 0 ) m_boundLines.push_back( TLineSegm(   x  *PIX_R, (x+1)*PIX_R, (y+1)*PIX_R, (y+1)*PIX_R) );
			}

			double c = 200;
			for( int i=0; i < WH; ++i) 
			{
				if( m_distField[i] > 0 ) m_imgDisp.setColor( 4*i, (byte)( m_distField[i]*c), 0,0);
				else                     m_imgDisp.setColor( 4*i, 0,0, (byte)( -m_distField[i]*c));
			}
			m_imgDisp.unbind( &m_ogl );
			m_ogl.RedrawWindow();
		}
	}

}








































