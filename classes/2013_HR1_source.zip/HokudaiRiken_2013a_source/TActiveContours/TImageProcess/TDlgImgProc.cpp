// TDlgImgProc.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "TImageProcess.h"
#include "TDlgImgProc.h"
#include "afxdialogex.h"
#include "TCore.h"


// TDlgImgProc �_�C�A���O

IMPLEMENT_DYNAMIC(TDlgImgProc, CDialogEx)

TDlgImgProc::TDlgImgProc(CWnd* pParent /*=NULL*/)
	: CDialogEx(TDlgImgProc::IDD, pParent)
{

}

TDlgImgProc::~TDlgImgProc()
{
}

void TDlgImgProc::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_1, m_slider_1);
	DDX_Control(pDX, IDC_SLIDER_2, m_slider_2);
	DDX_Control(pDX, IDC_SLIDER_3, m_slider_3);
	DDX_Control(pDX, IDC_SLIDER_4, m_slider_4);
	DDX_Control(pDX, IDC_SLIDER_5, m_slider_5);
	DDX_Control(pDX, IDC_SLIDER_6, m_slider_6);
}


BEGIN_MESSAGE_MAP(TDlgImgProc, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_SNAKES, &TDlgImgProc::OnBnClickedButtonSnakes)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_LEVELSET, &TDlgImgProc::OnBnClickedButtonLevelset)
END_MESSAGE_MAP()


// TDlgImgProc ���b�Z�[�W �n���h���[


BOOL TDlgImgProc::PreTranslateMessage(MSG* pMsg)
{
	if( WM_KEYDOWN == pMsg->message )
	{
		switch( pMsg->wParam )
		{
			case VK_RETURN:
				return FALSE;
			case VK_ESCAPE:
				return FALSE;
			default:
				break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL TDlgImgProc::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//����{�^���̖�����//
    CMenu*  pMenu = GetSystemMenu(FALSE);
    pMenu->EnableMenuItem(SC_CLOSE, MF_GRAYED);


	m_slider_1.SetRange(0, 150);  m_slider_1.SetPos(100);
	m_slider_2.SetRange(0, 150);  m_slider_2.SetPos( 20);
	m_slider_3.SetRange(0, 150);  m_slider_3.SetPos(  8);
	m_slider_4.SetRange(1, 3  );  m_slider_4.SetPos(  2);

	m_slider_5.SetRange(1,1000);  m_slider_5.SetPos( 300);
	m_slider_6.SetRange(1, 4000);  m_slider_6.SetPos( 100);

	CString str; 
	str.Format("%d"  , m_slider_1.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);
	str.Format("%d"  , m_slider_2.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_2))->SetWindowTextA(str);
	str.Format("%d"  , m_slider_3.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_3))->SetWindowTextA(str);
	str.Format("%d"  , m_slider_4.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_4))->SetWindowTextA(str);

	str.Format("%d"  , m_slider_5.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_5))->SetWindowTextA(str);
	str.Format("%.1f", (double)m_slider_6.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_6))->SetWindowTextA(str);



	return TRUE;  // return TRUE unless you set the focus to a control
}




void TDlgImgProc::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{

	CString str; 
	str.Format("%d", m_slider_1.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);
	str.Format("%d", m_slider_2.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_2))->SetWindowTextA(str);
	str.Format("%d", m_slider_3.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_3))->SetWindowTextA(str);
	str.Format("%d", m_slider_4.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_4))->SetWindowTextA(str);

	str.Format("%d"  , m_slider_5.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_5))->SetWindowTextA(str);
	str.Format("%.1f", (double)m_slider_6.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_6))->SetWindowTextA(str);

	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}




void TDlgImgProc::OnBnClickedButtonSnakes(){
	TCore::getInst()->runSnakes(20, m_slider_1.GetPos(), m_slider_2.GetPos(), m_slider_3.GetPos(), m_slider_4.GetPos());
}

void TDlgImgProc::OnBnClickedButtonLevelset(){
	TCore::getInst()->runLevelSet(m_slider_5.GetPos(), m_slider_6.GetPos() );
}
