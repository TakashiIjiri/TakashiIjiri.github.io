
// TImageProcessView.h : CTImageProcessView �N���X�̃C���^�[�t�F�C�X
//

#pragma once


#include <vector>
#include "TOGL.h"
using namespace std;


class CTImageProcessView : public CView
{
protected: // �V���A��������̂ݍ쐬���܂��B
	CTImageProcessView();
	DECLARE_DYNCREATE(CTImageProcessView)

// ����
public:
	CTImageProcessDoc* GetDocument() const;

// ����
public:

// �I�[�o�[���C�h
public:
	virtual void OnDraw(CDC* pDC);  // ���̃r���[��`�悷�邽�߂ɃI�[�o�[���C�h����܂��B
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ����
public:
	virtual ~CTImageProcessView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// �������ꂽ�A���b�Z�[�W���蓖�Ċ֐�
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove    ( UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel   ( UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDblClk( UINT nFlags, CPoint point);
	afx_msg void OnRButtonDblClk( UINT nFlags, CPoint point);
	afx_msg void OnMButtonDblClk( UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown  ( UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown  ( UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown  ( UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp    ( UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp    ( UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp    ( UINT nFlags, CPoint point);
	afx_msg void OnKeyDown      ( UINT nChar , UINT nRepCnt, UINT nFlags);



	vector< TVector3> m_contour;

	bool   m_bLButton, m_bRButton, m_bMButton; //flag of mouse mode
	bool   m_bTranslating, m_bZooming, m_bDrawStroke; //flags of interaction
	double m_transX, m_transY, m_zoom;//view parameter
	CPoint m_prePoint;//mouse point
	void convertCursorPosToWorldPos( const CPoint &point, double &x, double &y);


};

#ifndef _DEBUG  // TImageProcessView.cpp �̃f�o�b�O �o�[�W����
inline CTImageProcessDoc* CTImageProcessView::GetDocument() const
   { return reinterpret_cast<CTImageProcessDoc*>(m_pDocument); }
#endif

