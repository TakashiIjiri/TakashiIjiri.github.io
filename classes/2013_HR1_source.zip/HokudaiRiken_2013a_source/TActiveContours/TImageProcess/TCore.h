#pragma once

#include "TOGL.h"
#include "TDlgImgProc.h"
#include <vector>

using namespace std;




struct TLineSegm
{
public:
	double x1,x2,y1,y2;
	TLineSegm( double _x1, double _x2, double _y1, double _y2){
		x1 = _x1; x2 = _x2;
		y1 = _y1; y2 = _y2;
	}
};




class TCore
{
	vector< TVector3 > m_contour;
	
	TCore(void);
public:
	~TCore(void);
	inline static TCore* getInst(){ static TCore p; return &p;}
	
	TOGL_2D m_ogl;
	double  m_imgRectW, m_imgRectH;
	TDlgImgProc m_dlg;

	//�摜�f�[�^
	TOGL2DImage  m_imgOrig; //���摜
	TOGL2DImage  m_imgDisp; //�\���p�摜

	double      *m_gradMag; //���z���x
	double      *m_distField; //level set�̓��}�֐�
	double       m_ROT_X;
	double       m_ROT_Z;


	//���E��
	vector< TLineSegm > m_boundLines;

	void drawScene();
	void setInitialActiveContour(vector<TVector3> initContour);
	void runSnakes  (const int MAX_ITERATION, double C1, double C2, double C3, int WindowR);
	void runLevelSet(const int MAX_ITERATION, double A );
};

