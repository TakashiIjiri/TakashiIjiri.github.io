#include "StdAfx.h"
#include "TCore.h"


#ifndef MIN3
#define MIN3(  a,b,c)	((a)<(b)?((a)<(c)?(a):(c)):((b)<(c)?(b):(c)))
#define MAX3(  a,b,c)	((a)>(b)?((a)>(c)?(a):(c)):((b)>(c)?(b):(c)))
#define MIN3ID(a,b,c)	((a)<(b)?((a)<(c)?(0):(2)):((b)<(c)?(1):(2)))
#define MAX3ID(a,b,c)	((a)>(b)?((a)>(c)?(0):(2)):((b)>(c)?(1):(2)))
template <class T> T   max3  (T a,T b,T c){return MAX3(  a,b,c);}
template <class T> int max3id(T a,T b,T c){return MAX3ID(a,b,c);}
template <class T> T   min3  (T a,T b,T c){return MIN3(  a,b,c);}
template <class T> int min3id(T a,T b,T c){return MIN3ID(a,b,c);}
#endif

#define IMG_RECT_SIZE  7.0
#define COLOR_COEF     0.02745
//COLOR_COEF = 7 / 255


#ifdef _DEBUG
#define new DEBUG_NEW
#endif



TCore::~TCore(void){
}

TCore::TCore(void)
{
	m_ROT_X = -70;
	m_ROT_Z =  20;

	//load image
	CString         filter("bmp Files (*.bmp;*.bmp)|*.bmp; *.bmp||");
	CFileDialog     selDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, filter);
	bool inverted;
	if (selDlg.DoModal() == IDOK) m_imgOrig.allocateFromFile( selDlg.GetPathName(), inverted, &m_ogl );
	else exit(1);
	if( inverted ) m_imgOrig.flipImageInY();
	                                           
	m_imgDisp  .allocateImage( m_imgOrig, 0 ); 
	m_imgOrig  .m_DoInterpolation = false;
	m_imgDisp  .m_DoInterpolation = false;

	const int W = m_imgOrig.m_width ;
	const int H = m_imgOrig.m_height;
	const int WH = W*H;
	m_imgRectW = IMG_RECT_SIZE;
	m_imgRectH = IMG_RECT_SIZE / (double) W * H;

	m_dlg.Create( IDD_DIALOG_IMGPRC );
	m_dlg.ShowWindow( SW_SHOW );
}






void t_drawMarker(const double x, const double y, const double z, const double r)
{
	glTranslated( x,y,z );
	glBegin( GL_QUADS );

	glNormal3d( 0,0,1 );
	glVertex3d( -r, -r, -r); glVertex3d(  r, -r, -r); glVertex3d(  r,  r, -r); glVertex3d( -r,  r, -r);
	glVertex3d( -r, -r,  r); glVertex3d(  r, -r,  r); glVertex3d(  r,  r,  r); glVertex3d( -r,  r,  r);

	glNormal3d( 0,1,0 );
	glVertex3d( -r, -r, -r); glVertex3d(  r, -r, -r); glVertex3d(  r, -r,  r); glVertex3d( -r, -r,  r);
	glVertex3d( -r,  r, -r); glVertex3d(  r,  r, -r); glVertex3d(  r,  r,  r); glVertex3d( -r,  r,  r);

	glNormal3d( 1,0,0 );
	glVertex3d( -r, -r, -r); glVertex3d( -r, -r,  r); glVertex3d( -r,  r,  r); glVertex3d( -r,  r, -r);
	glVertex3d(  r, -r, -r); glVertex3d(  r, -r,  r); glVertex3d(  r,  r,  r); glVertex3d(  r,  r, -r);
	glEnd();
	glTranslated( -x,-y,-z );
}





static void drawImage( const double rectW, const double rectH, TOGL2DImage &img)
{
	glDisable( GL_LIGHTING  );
	glDisable( GL_CULL_FACE );
	glColor3d( 1,1,1        );
	glEnable( GL_TEXTURE_2D );
	img.bind(0);
	glBegin  ( GL_QUADS     );
	glTexCoord2d(0,0); glVertex3d(     0,    0, 0 );
	glTexCoord2d(1,0); glVertex3d( rectW,    0, 0 );
	glTexCoord2d(1,1); glVertex3d( rectW,rectH, 0 );
	glTexCoord2d(0,1); glVertex3d(     0,rectH, 0 );
	glEnd( );
	glDisable( GL_TEXTURE_2D );
}



void TCore::drawScene()
{
	const int W = m_imgOrig.m_width  ;
	const int H = m_imgOrig.m_height , WH = W*H ;
	const byte *rgba = m_imgOrig.m_RGBA;
	
	
	{		
		float shin[1] = {32.0f};
		float spec[4] = {1,1,1,1};
		float diff[4] = {0.3f, 0.8f, 0.1f,0.5f};
		float ambi[4] = {0.1f, 0.2f, 0.2f,0.5f};
		glEnable( GL_LIGHTING );
		glEnable( GL_LIGHT0 );
		glEnable( GL_LIGHT1 );
		glEnable( GL_LIGHT2 );
		glMaterialfv( GL_FRONT_AND_BACK, GL_SHININESS, shin );
		glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR,  spec );
		glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE,   diff );
		glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT,   ambi );
	}
	
	
	
	
	glDisable( GL_LIGHTING );

	glColor3d( 1,1,0 );
	glLineWidth( 3 );
	glBegin( GL_LINE_STRIP );
		glVertex3d( 0,0,0);
		glVertex3d( m_imgRectW,0,0);
		glVertex3d( m_imgRectW,m_imgRectH,0);
		glVertex3d( 0,m_imgRectH,0);
		glVertex3d( 0,0,0);
	glEnd();


	glPushMatrix();
		drawImage( m_imgRectW, m_imgRectH, m_imgDisp   ); 
		glTranslated( 0, m_imgRectH * 1.1, 0); 
		drawImage( m_imgRectW, m_imgRectH, m_imgOrig  );
	glPopMatrix();


	//RGB ���z
	glPushMatrix();
		glTranslated( -IMG_RECT_SIZE * 1.1,0,0 );
		glRotated( m_ROT_X, 1,0,0);
		glRotated( m_ROT_Z, 0,0,1);
		glTranslated( -IMG_RECT_SIZE * 0.5, - IMG_RECT_SIZE * 0.5,  IMG_RECT_SIZE * 0.5 );


		glLineWidth( 5 );
		glBegin( GL_LINE_STRIP );
			glColor3d( 1,0,0 ); glVertex3d( 0,0,0); glVertex3d( IMG_RECT_SIZE,0,0);
			glColor3d( 0,1,0 ); glVertex3d( 0,0,0); glVertex3d( 0,IMG_RECT_SIZE,0);
			glColor3d( 0,0,1 ); glVertex3d( 0,0,0); glVertex3d( 0,0,IMG_RECT_SIZE);
		glEnd();                                                       

		glColor3d( 0.5,0.2,0  );
		glBegin( GL_QUADS );
			glVertex3d( 0,0,0 );glVertex3d( IMG_RECT_SIZE,0,0 );
			glVertex3d( IMG_RECT_SIZE,IMG_RECT_SIZE,0 ); glVertex3d( 0,IMG_RECT_SIZE,0 );
		glEnd();

		glPointSize( 2 );
		glBegin( GL_POINTS );
		for( int i=0; i<WH; ++i) {
			glColor3d ( rgba[i*4] / 255.0, rgba[i*4+1] / 255.0, rgba[i*4+2] / 255.0 );
			glVertex3d( rgba[i*4] * COLOR_COEF, rgba[i*4+1] * COLOR_COEF, rgba[i*4+2] * COLOR_COEF    ); 
		}
		glEnd();

		glEnable( GL_LIGHTING );
		for( int i=0; i < (int) m_cluster_color.size(); ++i)
			t_drawMarker( m_cluster_color[i][0] * COLOR_COEF, 
			              m_cluster_color[i][1] * COLOR_COEF, 
						  m_cluster_color[i][2] * COLOR_COEF, 0.1 );
		glDisable( GL_LIGHTING);

	glPopMatrix();


	//Bilateral ���z
	glPushMatrix();
		glTranslated( IMG_RECT_SIZE * 1.9,0,0 );
		glRotated( m_ROT_X, 1,0,0);
		glRotated( m_ROT_Z, 0,0,1);
		glTranslated( -IMG_RECT_SIZE * 0.5, - IMG_RECT_SIZE * 0.5,  IMG_RECT_SIZE * 0.5 );

		glLineWidth( 5 );
		glBegin( GL_LINE_STRIP );
			glColor3d( 0,0,0 ); glVertex3d( 0,0,0); glVertex3d( IMG_RECT_SIZE,0,0);
			glColor3d( 0,0,0 ); glVertex3d( 0,0,0); glVertex3d( 0,IMG_RECT_SIZE,0);
			glColor3d( 1,0,0 ); glVertex3d( 0,0,0); glVertex3d( 0,0,IMG_RECT_SIZE);
		glEnd();                                                       
		glColor3d( 0.5,0.2,0  );
		glBegin( GL_QUADS );
			glVertex3d( 0,0,0 );glVertex3d( IMG_RECT_SIZE,0,0 );
			glVertex3d( IMG_RECT_SIZE,IMG_RECT_SIZE,0 ); glVertex3d( 0,IMG_RECT_SIZE,0 );
		glEnd();

		glPointSize( 2 );
		glBegin( GL_POINTS );
		for( int y=0, i=0; y<H; ++y     ) 
		for( int x=0     ; x<W; ++x, ++i) 
		{
			glColor3d ( rgba[i*4] / 255.0, rgba[i*4+1] / 255.0, rgba[i*4+2] / 255.0 );
			glVertex3d( x / (double)W * IMG_RECT_SIZE, y /(double) H * IMG_RECT_SIZE, 0.7 * rgba[i*4] * COLOR_COEF ); 
		}
		glEnd();

		glEnable( GL_LIGHTING );
		for( int i=0; i < (int) m_cluster_BiLate.size(); ++i)
			t_drawMarker( m_cluster_BiLate[i].data[0] * IMG_RECT_SIZE, 
			              m_cluster_BiLate[i].data[1] * IMG_RECT_SIZE, 
						  m_cluster_BiLate[i].data[2] * IMG_RECT_SIZE * 0.7, 0.1 );
		glDisable( GL_LIGHTING);


	glPopMatrix();


}














static double calcColorDist( const byte *rgba, const TVector3 &color)
{
	return (rgba[0] - color[0]) * (rgba[0] - color[0])
		 + (rgba[1] - color[1]) * (rgba[1] - color[1])
		 + (rgba[2] - color[2]) * (rgba[2] - color[2]);
}


void TCore::RunKMeanClustering_color    ( int K )
{
	const int W = m_imgOrig.m_width  ;
	const int H = m_imgOrig.m_height , WH = W*H ;
	const byte *rgba = m_imgOrig.m_RGBA;

	//center������---------------------------------------------------
	m_cluster_color.resize( K );
	int *imgClusterIdx = new int[WH];//�e��f���ǂ̃N���X�^�Ɋ܂܂�邩

	for( int i =0; i < WH; ++i) imgClusterIdx[i] = (int)( (K-1.0)* ( rand()/(double)RAND_MAX) );




	//iteration 
	const int ITR_MAX = 80;
	for( int iteration = 0; iteration < ITR_MAX; ++iteration)
	{
		//update center position------------
		vector< int > tmpClusterNum(K, 0);

		for( int i=0; i<K; ++i) m_cluster_color[i].Set(0,0,0);

		for( int i=0; i<WH; ++i){
			tmpClusterNum[ imgClusterIdx [i] ] ++;
			m_cluster_color[ imgClusterIdx [i] ][0] +=  rgba[ 4*i   ];
			m_cluster_color[ imgClusterIdx [i] ][1] +=  rgba[ 4*i+1 ];
			m_cluster_color[ imgClusterIdx [i] ][2] +=  rgba[ 4*i+2 ];
		}
		
		for( int i=0; i<K; ++i) if(  tmpClusterNum[ i ] != 0 ){
			m_cluster_color[ i ][0] /= tmpClusterNum[ i ];
			m_cluster_color[ i ][1] /= tmpClusterNum[ i ];
			m_cluster_color[ i ][2] /= tmpClusterNum[ i ];
		}

		//
		bool bUpdateExist = false;

		//calc new clustering---------------
		for( int i=0; i<WH; ++i)
		{
			double mindist = DBL_MAX;
			for( int kkk =0; kkk < K; ++kkk)
			{
				double d = calcColorDist( &rgba[ 4*i], m_cluster_color[ kkk ] );
				if( d < mindist ) {
					mindist      = d   ;
					imgClusterIdx [i]  = kkk ;
					bUpdateExist = true;
				}
			}
		}

		if( !bUpdateExist ) break;

		if( iteration % 10 == 0 ) fprintf( stderr, "iteration %d\n", iteration );

		for( int i=0; i<WH; ++i) {
			m_imgDisp.m_RGBA[i*4+0] = (byte)m_cluster_color[ imgClusterIdx [i] ].data[0];
			m_imgDisp.m_RGBA[i*4+1] = (byte)m_cluster_color[ imgClusterIdx [i] ].data[1];
			m_imgDisp.m_RGBA[i*4+2] = (byte)m_cluster_color[ imgClusterIdx [i] ].data[2];		
		}
		m_imgDisp.unbind( &m_ogl );
		m_ogl.RedrawWindow();
		Sleep( 10 );
	}

	delete[] imgClusterIdx;
}












void TCore::RunKMeanClustering_bilateral( int K )
{
	const int W = m_imgOrig.m_width  ;
	const int H = m_imgOrig.m_height , WH = W*H ;
	const byte *rgba = m_imgOrig.m_RGBA;

	//�ʒu��� ��f�l��ԂƂ��� [0,1]�ɐ��K��
	const double X_COEF = 1 / (double) (W-1);
	const double Y_COEF = 1 / (double) (H-1);
	const double C_COEF = 1 / 255.0;


	//center������---------------------------------------------------
	m_cluster_BiLate.clear();
	m_cluster_BiLate.resize( K );
	int *imgClusterIdx = new int[WH];//�e��f���ǂ̃N���X�^�Ɋ܂܂�邩
	for( int i=0; i < WH; ++i) imgClusterIdx[i] = (int)( (K-1.0)* ( rand()/(double)RAND_MAX) );




	//iteration 
	const int ITR_MAX = 100;
	for( int iteration = 0; iteration < ITR_MAX; ++iteration)
	{
		
		//update center position------------
		vector< int > tmpClusterNum(K, 0);

		for( int i=0; i<K; ++i) m_cluster_BiLate[i].Set(0,0,0,0,0);

		for( int y = 0; y < H; ++y )
		for( int x = 0; x < W; ++x )
		{
			int i= x + y *W ;
			tmpClusterNum[ imgClusterIdx [i] ] ++;
			m_cluster_BiLate[ imgClusterIdx[i] ].data[0] +=  x            * X_COEF;
			m_cluster_BiLate[ imgClusterIdx[i] ].data[1] +=  y            * Y_COEF;
			m_cluster_BiLate[ imgClusterIdx[i] ].data[2] +=  rgba[ 4*i  ] * C_COEF;
			m_cluster_BiLate[ imgClusterIdx[i] ].data[3] +=  rgba[ 4*i+1] * C_COEF;
			m_cluster_BiLate[ imgClusterIdx[i] ].data[4] +=  rgba[ 4*i+2] * C_COEF;
		}
		
		for( int i=0; i<K; ++i) if(  tmpClusterNum[ i ] != 0 ){
			m_cluster_BiLate[ i ].data[0] /= tmpClusterNum[ i ];
			m_cluster_BiLate[ i ].data[1] /= tmpClusterNum[ i ];
			m_cluster_BiLate[ i ].data[2] /= tmpClusterNum[ i ];
			m_cluster_BiLate[ i ].data[3] /= tmpClusterNum[ i ];
			m_cluster_BiLate[ i ].data[4] /= tmpClusterNum[ i ];
		}


		//calc new clustering---------------
		bool bUpdateExist = false;
		for( int y = 0, i = 0; y < H; ++y     )
		for( int x = 0       ; x < W; ++x, ++i)
		{
			double mindist = DBL_MAX;

			for( int kkk =0; kkk < K; ++kkk)
			{
				double d = (     x      * X_COEF - m_cluster_BiLate[ kkk ].data[0]) *  (     x      * X_COEF - m_cluster_BiLate[ kkk ].data[0])
					     + (     y      * Y_COEF - m_cluster_BiLate[ kkk ].data[1]) *  (     y      * Y_COEF - m_cluster_BiLate[ kkk ].data[1])
					     + ( rgba[4*i  ]* C_COEF - m_cluster_BiLate[ kkk ].data[2]) *  ( rgba[4*i  ]* C_COEF - m_cluster_BiLate[ kkk ].data[2])
					     + ( rgba[4*i+1]* C_COEF - m_cluster_BiLate[ kkk ].data[3]) *  ( rgba[4*i+1]* C_COEF - m_cluster_BiLate[ kkk ].data[3])
					     + ( rgba[4*i+2]* C_COEF - m_cluster_BiLate[ kkk ].data[4]) *  ( rgba[4*i+2]* C_COEF - m_cluster_BiLate[ kkk ].data[4]);

				if( d < mindist ) {
					mindist      = d   ;
					imgClusterIdx [i]  = kkk ;
					bUpdateExist = true;
				}
			}
		}

		if( !bUpdateExist ) break;


		//�����p
		for( int i=0; i<WH; ++i) {
			m_imgDisp.m_RGBA[i*4+0] = (byte)( 255 * m_cluster_BiLate[ imgClusterIdx [i] ].data[2]);
			m_imgDisp.m_RGBA[i*4+1] = (byte)( 255 * m_cluster_BiLate[ imgClusterIdx [i] ].data[3]);
			m_imgDisp.m_RGBA[i*4+2] = (byte)( 255 * m_cluster_BiLate[ imgClusterIdx [i] ].data[4]);		
		}
		m_imgDisp.unbind( &m_ogl );
		m_ogl.RedrawWindow();
		if( iteration % 10 == 0 ) fprintf( stderr, "iteration %d\n", iteration );
	}

	delete[] imgClusterIdx;




}













































