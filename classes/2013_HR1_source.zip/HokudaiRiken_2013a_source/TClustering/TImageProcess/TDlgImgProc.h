#pragma once

#include "resource.h"
#include "afxcmn.h"

// TDlgImgProc �_�C�A���O

class TDlgImgProc : public CDialogEx
{
	DECLARE_DYNAMIC(TDlgImgProc)

public:
	TDlgImgProc(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~TDlgImgProc();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DIALOG_IMGPRC };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	CSliderCtrl m_slider_1;
	afx_msg void OnBnClickedButtonKmeanColor();
	afx_msg void OnBnClickedButtonKmeanBilate();
};
