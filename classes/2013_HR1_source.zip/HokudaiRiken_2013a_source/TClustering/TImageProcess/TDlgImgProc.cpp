// TDlgImgProc.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "TImageProcess.h"
#include "TDlgImgProc.h"
#include "afxdialogex.h"
#include "TCore.h"


// TDlgImgProc �_�C�A���O

IMPLEMENT_DYNAMIC(TDlgImgProc, CDialogEx)

TDlgImgProc::TDlgImgProc(CWnd* pParent /*=NULL*/)
	: CDialogEx(TDlgImgProc::IDD, pParent)
{

}

TDlgImgProc::~TDlgImgProc()
{
}

void TDlgImgProc::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_1, m_slider_1);
}


BEGIN_MESSAGE_MAP(TDlgImgProc, CDialogEx)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_KMEAN_COLOR, &TDlgImgProc::OnBnClickedButtonKmeanColor)
	ON_BN_CLICKED(IDC_BUTTON_KMEAN_BILATE, &TDlgImgProc::OnBnClickedButtonKmeanBilate)
END_MESSAGE_MAP()


// TDlgImgProc ���b�Z�[�W �n���h���[


BOOL TDlgImgProc::PreTranslateMessage(MSG* pMsg)
{
	if( WM_KEYDOWN == pMsg->message )
	{
		switch( pMsg->wParam )
		{
			case VK_RETURN:
				return FALSE;
			case VK_ESCAPE:
				return FALSE;
			default:
				break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL TDlgImgProc::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//����{�^���̖�����//
    CMenu*  pMenu = GetSystemMenu(FALSE);
    pMenu->EnableMenuItem(SC_CLOSE, MF_GRAYED);

	m_slider_1.SetRange( 2, 50);
	m_slider_1.SetPos( 15 );
	CString str; 
	str.Format("%d"  , m_slider_1.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);


	return TRUE;  // return TRUE unless you set the focus to a control
}




void TDlgImgProc::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{

	if( *pScrollBar == m_slider_1 ){
		CString str; 
		str.Format("%d", m_slider_1.GetPos()); ((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);
		CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
	}
}







void TDlgImgProc::OnBnClickedButtonKmeanColor()
{
	TCore::getInst()->RunKMeanClustering_color(m_slider_1.GetPos());
	TCore::getInst()->m_ogl.RedrawWindow();

}


void TDlgImgProc::OnBnClickedButtonKmeanBilate()
{
	TCore::getInst()->RunKMeanClustering_bilateral(m_slider_1.GetPos());
	TCore::getInst()->m_ogl.RedrawWindow();
}
