#pragma once

#include "TOGL.h"
#include "TDlgImgProc.h"
#include <vector>

using namespace std;



struct TCluster5D //x,y,r,g,b
{
	double data[5];
	TCluster5D(){ 
		data[0] = data[1] = data[2] = data[3] = data[4] = 0;
	}
	void Set( double d0, double d1, double d2, double d3, double d4)
	{
		data[0] = d0;//x
		data[1] = d1;//y
		data[2] = d2;//r
		data[3] = d3;//g
		data[4] = d4;//b
	}
};




class TCore
{
	TCore(void);
public:
	~TCore(void);
	inline static TCore* getInst(){ static TCore p; return &p;}
	
	TOGL_2D     m_ogl;
	double      m_imgRectW, m_imgRectH;
	TDlgImgProc m_dlg;

	//�摜�f�[�^
	TOGL2DImage  m_imgOrig; //���摜
	TOGL2DImage  m_imgDisp; //�\���p�摜

	double       m_ROT_X;
	double       m_ROT_Z;

	//���E��

	vector< TVector3   > m_cluster_color ;//�F��Ԃɂ����� �N���X�^�ʒu
	vector< TCluster5D > m_cluster_BiLate;//�F��Ԃɂ����� �N���X�^�ʒu


	void drawScene();
	void RunKMeanClustering_color    ( int k );
	void RunKMeanClustering_bilateral( int k );
};

