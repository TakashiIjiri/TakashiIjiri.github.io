#pragma once

#include "TOGL.h"
#include "TDlgImageProc.h"

#include <vector>
using namespace std;


#define CP_RECT_SIZE     0.1


//graph cut segmentation�̐���_
struct TConstPoint
{
public:
	double m_x, m_y;

	TConstPoint( double x, double y){
		m_x  = x;
		m_y  = y;
	}
};




struct TLineSegm
{
public:
	double x1,x2,y1,y2;
	TLineSegm( double _x1, double _x2, double _y1, double _y2){
		x1 = _x1; x2 = _x2;
		y1 = _y1; y2 = _y2;
	}
};









class TCore
{
	TCore(void);
public:
	~TCore(void);
	inline static TCore* getInst(){ static TCore p; return &p;}
	
	TOGL_2D m_ogl;
	double  m_imgRectW, m_imgRectH;
	TDlgImageProc m_dlg;

	//�摜
	TOGL2DImage  m_imgOrig; //���摜
	TOGL2DImage  m_imgDisp; //�\���p�摜

	//����_
	vector< TConstPoint > m_CPs;

	//���E��
	vector< TLineSegm > m_boundLines;


	void drawScene();
	void runRegionGrowing( int r );
	void runRegionGrowing_multiRegion();
	void runWatershedSegmentation    ();


	//interface for control points//
	int addCP   ( const double x, const double y){
		if( x< 0 || m_imgRectW < x || y<0 || m_imgRectH<y) return -1;
		m_CPs.push_back( TConstPoint(x,y) ); 
		return (int) m_CPs.size() -1;
	}
	void moveCP  ( const int cpIdx, const double x, const double y){
		if( x< 0 || m_imgRectW < x || y<0 || m_imgRectH<y) return;
		m_CPs[cpIdx].m_x = x; m_CPs[cpIdx].m_y = y; 
	}
	void removeCP( const int cpIdx){m_CPs.erase( m_CPs.begin() + cpIdx ); }
	int  pickCP  ( const double x, const double y){
		for( int i=0; i<(int)m_CPs.size(); ++i){
			if( m_CPs[i].m_x - CP_RECT_SIZE <= x && x <= m_CPs[i].m_x + CP_RECT_SIZE && 
				m_CPs[i].m_y - CP_RECT_SIZE <= y && y <= m_CPs[i].m_y + CP_RECT_SIZE ) return i; 
		}
		return -1;
	}



};

