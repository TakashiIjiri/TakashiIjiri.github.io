#include "StdAfx.h"
#include "TCore.h"
#include <queue>
#include <map>
#include <set>
#include "TWatershedEx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif




TCore::~TCore(void){}

TCore::TCore(void)
{
	//load image
	CString         filter("bmp Files (*.bmp;*.bmp)|*.bmp; *.bmp||");
	CFileDialog     selDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, filter);
	bool inverted;
	if (selDlg.DoModal() == IDOK) m_imgOrig.allocateFromFile( selDlg.GetPathName(), inverted, &m_ogl );
	else exit(1);
	if( inverted ) m_imgOrig.flipImageInY();

	//�T�C�Y�擾
	const int W = m_imgOrig.m_width ;
	const int H = m_imgOrig.m_height;
	const int WH = W*H;
	m_imgRectW = 7.0;
	m_imgRectH = 7.0 / (double) W * H;

	m_imgDisp.allocateImage( m_imgOrig, 0 ); 
	m_imgDisp.m_DoInterpolation = false;
	m_imgOrig.m_DoInterpolation = false;

	m_dlg.Create( IDD_DIALOG_IMGPRC );
	m_dlg.ShowWindow( SW_SHOW );
}




static void drawImage( const double rectW, const double rectH, TOGL2DImage &img)
{
	glDisable( GL_LIGHTING  );
	glDisable( GL_CULL_FACE );
	glColor3d( 1,1,1        );
	glEnable( GL_TEXTURE_2D );
	img.bind(0);
	glBegin  ( GL_QUADS     );
	glTexCoord2d(0,0); glVertex3d(     0,    0, 0 );
	glTexCoord2d(1,0); glVertex3d( rectW,    0, 0 );
	glTexCoord2d(1,1); glVertex3d( rectW,rectH, 0 );
	glTexCoord2d(0,1); glVertex3d(     0,rectH, 0 );
	glEnd( );
	glDisable( GL_TEXTURE_2D );
}



static void drawCpRect(  const double x, const double y, const double rectR )
{
	glBegin  ( GL_QUADS     );
	glTexCoord2d(0,0); glVertex3d( x-rectR,y-rectR, 1 );
	glTexCoord2d(1,0); glVertex3d( x+rectR,y-rectR, 1 );
	glTexCoord2d(1,1); glVertex3d( x+rectR,y+rectR, 1 );
	glTexCoord2d(0,1); glVertex3d( x-rectR,y+rectR, 1 );
	glEnd( );
}



void TCore::drawScene()
{
	const int W = m_imgOrig.m_width  ;
	const int H = m_imgOrig.m_height ;	
	glDisable( GL_LIGHTING );

	for( int i=0,s=(int)m_CPs.size(); i<s; ++i){
		glColor3d( 1,0,0 );
		drawCpRect( m_CPs[i].m_x, m_CPs[i].m_y, CP_RECT_SIZE );
	}

	//draw boundary
	glLineWidth( 1 );

	glColor3d( 1,1,0);
	glBegin( GL_LINES );
	for( int i=0, s=(int)m_boundLines.size(); i<s; ++i){ 
		glVertex3d( m_boundLines[i].x1, m_boundLines[i].y1, 0.1 ); 
		glVertex3d( m_boundLines[i].x2, m_boundLines[i].y2, 0.1 ); 
	}
	glEnd();


	glLineWidth( 5 );
	glColor3d( 1,1,0);
	glBegin( GL_LINE_STRIP );
	glVertex3d( 0,0,0 );
	glVertex3d( m_imgRectW,0,0 );
	glVertex3d( m_imgRectW,m_imgRectH,0 );
	glVertex3d( 0,m_imgRectH,0 );
	glVertex3d( 0,0,0 );
	glEnd();

	glPushMatrix();
	drawImage( m_imgRectW, m_imgRectH, m_imgOrig   );
	glTranslated(   m_imgRectW + 0.5, 0, 0); 
	drawImage( m_imgRectW, m_imgRectH, m_imgDisp   );
	glPopMatrix();
}




struct PixInfo
{
	int x, y, idx;
	PixInfo( int _x, int _y, int _idx)
	{
		x = _x;
		y = _y;
		idx = _idx	;
	}
};



static double distColor( byte R, byte G, byte B, const byte *rgba, int I)
{
	const int I4 = I*4;

	double d =  (rgba[I4  ] - R) * (rgba[I4  ] - R) + 
				(rgba[I4+1] - G) * (rgba[I4+1] - G) + 
				(rgba[I4+2] - B) * (rgba[I4+2] - B) ; 
	return sqrt( d ) / 3; 
}






void TCore::runRegionGrowing( int r )
{

	const int   W    = m_imgOrig.m_width  ;
	const int   H    = m_imgOrig.m_height ;	
	const byte *rgba = m_imgOrig.m_RGBA   ;

	if( m_CPs.size() > 1 ) AfxMessageBox( "����_����������̂�\n��K���ɑI��ł�������Region Growing���܂�");
	if( m_CPs.size() == 0) {AfxMessageBox( "����_������܂���"); return ;}
	
	TConstPoint p = m_CPs[ (int)( rand() / (double)RAND_MAX * (m_CPs.size()-1) ) ];
	const int  SeedX = (int) ( p.m_x / m_imgRectW * W);
	const int  SeedY = (int) ( p.m_y / m_imgRectH * H);
	const int  SeedIdx = SeedX + SeedY*W;
	const byte SeedR = rgba[ SeedIdx*4 + 0];
	const byte SeedG = rgba[ SeedIdx*4 + 1];
	const byte SeedB = rgba[ SeedIdx*4 + 2];
	


	byte *imgFlg = new byte[W*H];// 0:not yet,  1 visited (fore)  2visited (back)
	memset( imgFlg, 0, sizeof( byte ) * W*H );

	queue< PixInfo > fronteer;
	fronteer.push( PixInfo( SeedX, SeedY, SeedIdx ) );
	imgFlg [ SeedIdx ] = 0;


	int c = 0;

	while( !fronteer.empty() )
	{
		const int X = fronteer.front().x  ;
		const int Y = fronteer.front().y  ;
		const int I = fronteer.front().idx;
		fronteer.pop();

		if( imgFlg[I] != 0 ) continue;

		imgFlg[I] = ( distColor( SeedR, SeedG, SeedB, rgba, I) < r ) ? 1 : 2; 

		if( imgFlg[I] == 1 ) //grow
		{
			if( X > 0  && imgFlg[ I-1 ] ==0 ){ fronteer.push( PixInfo( X-1, Y  , I-1) );  }
			if( X <W-1 && imgFlg[ I+1 ] ==0 ){ fronteer.push( PixInfo( X+1, Y  , I+1) );  }
			if( Y >  0 && imgFlg[ I-W ] ==0 ){ fronteer.push( PixInfo( X  , Y-1, I-W) );  }
			if( Y <H-1 && imgFlg[ I+W ] ==0 ){ fronteer.push( PixInfo( X  , Y+1, I+W) );  }
		}

		//for visualization
		++c;
		if( c % 500 == 0) 
		{
			double PIX_R = m_imgRectW / (double)W;
			m_boundLines.clear(); 
			for( int y=0; y<H-1; ++y )
			for( int x=0; x<W-1; ++x ){
				int i = x + y * W;
				if( (imgFlg[i] ==1 && imgFlg[i+1] !=1) || (imgFlg[i] !=1 && imgFlg[i+1] ==1) ) m_boundLines.push_back( TLineSegm( (x+1)*PIX_R, (x+1)*PIX_R,  y   *PIX_R, (y+1)*PIX_R) );
				if( (imgFlg[i] ==1 && imgFlg[i+W] !=1) || (imgFlg[i] !=1 && imgFlg[i+W] ==1) ) m_boundLines.push_back( TLineSegm(   x  *PIX_R, (x+1)*PIX_R, (y+1)*PIX_R, (y+1)*PIX_R) );
			}
			memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
			for( int i=0; i< W*H; ++i) if( imgFlg[i] != 1 ) m_imgDisp.setColor(i*4, 0,0,255);
			m_imgDisp.unbind( &m_ogl );
			m_ogl.RedrawWindow();
		}
	}

	//���Ɖ摜���X�V
	double PIX_R = m_imgRectW / (double)W;
	m_boundLines.clear(); 
	for( int y=0; y<H-1; ++y )
	for( int x=0; x<W-1; ++x ){
		int i = x + y * W;
		if( (imgFlg[i] ==1 && imgFlg[i+1] !=1) || (imgFlg[i] !=1 && imgFlg[i+1] ==1) ) m_boundLines.push_back( TLineSegm( (x+1)*PIX_R, (x+1)*PIX_R,  y   *PIX_R, (y+1)*PIX_R) );
		if( (imgFlg[i] ==1 && imgFlg[i+W] !=1) || (imgFlg[i] !=1 && imgFlg[i+W] ==1) ) m_boundLines.push_back( TLineSegm(   x  *PIX_R, (x+1)*PIX_R, (y+1)*PIX_R, (y+1)*PIX_R) );
	}
	memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
	for( int i=0; i< W*H; ++i) if( imgFlg[i] != 1 ) m_imgDisp.setColor(i*4, 0,0,255);
	m_imgDisp.unbind( &m_ogl );

	m_ogl.RedrawWindow();

	delete[] imgFlg;
}



struct TRegionInfo
{
	int pixNum;
	TVector3 meanCol, sumCol;
	TRegionInfo()
	{
		pixNum = 0;
		meanCol.Set(0,0,0);
		sumCol .Set(0,0,0);
	}

	void addPixel( byte r, byte g, byte b)
	{
		pixNum++;
		sumCol.data[0] += r; meanCol.data[0] = sumCol.data[0] / pixNum;
		sumCol.data[1] += g; meanCol.data[1] = sumCol.data[1] / pixNum;
		sumCol.data[2] += b; meanCol.data[2] = sumCol.data[2] / pixNum;

	}
};




static double colorDist(const TVector3 &c1, const byte *rgba, int I4){
	return sqrt( (c1.data[0]-rgba[I4  ]) * (c1.data[0]-rgba[I4  ]) + 
		         (c1.data[1]-rgba[I4+1]) * (c1.data[1]-rgba[I4+1]) + 
				 (c1.data[2]-rgba[I4+2]) * (c1.data[2]-rgba[I4+2]) );
}







/*------------------------------------------------------------------------------------------------------
Adams��� Seede Region Growing���������� (�̈�̐����ɔ����̈�̕��ϐF�̕ω��͍l�����Ȃ�����)

1) Seed��f�ɈقȂ郉�x���l������
2) Seed��f�̋ߖT�� �v���C�I���e�B�L���[ Q�ɐς�

3) Q����łȂ�����ȉ����J��Ԃ�
	3-1) Q����y���|�b�v
	3-1) y�̋ߖT��f�̂������x���t��������ł�����̂𑖍����S�Ă��������x�����m�F
	3-1-YES) 
	     y�ɗאڗ̈惉�x������
		 ���������̈�̕��ς��f�l���X�V
		 y�̋ߖT�̓��AQ�ɓ����Ă��炸�A���x���t��������Ă��Ȃ���f��Q�ɑ���
	3-1-NO ) y�ɋ��E���x��������
------------------------------------------------------------------------------------------------------*/
void TCore::runRegionGrowing_multiRegion()
{
	m_boundLines.clear(); 
	
	const int   W    = m_imgOrig.m_width  ;
	const int   H    = m_imgOrig.m_height, WH = W*H ;	
	const byte *rgba = m_imgOrig.m_RGBA   ;

	if( m_CPs.size() <= 1) {AfxMessageBox( "�����̐���_���K�v�ł�"); return;}


	int *imgFlg = new int[ WH ]; //0:not yet, ���l:�̈�ID�C-1:���E���x��, -2:�v���C�I���e�B�L���[��
	memset( imgFlg, 0, sizeof( int ) * WH );

	
	//1) Seed��f�ɈقȂ郉�x���l������
	//2) Seed��f�̋ߖT�� �v���C�I���e�B�L���[ Q�ɐς�
	const int region_num = m_CPs.size();
	vector< TRegionInfo > regions( region_num );
	multimap<double, PixInfo> boundPix;

	for( int r = 0; r <(int)m_CPs.size(); ++r)
	{
		const int  x   = (int) ( m_CPs[r].m_x / m_imgRectW * W);
		const int  y   = (int) ( m_CPs[r].m_y / m_imgRectH * H);
		const int  Idx = x + y * W;

		if( imgFlg[ Idx] == 0 ) 
		{
			imgFlg[ Idx] = r + 1;
			regions[r].addPixel( rgba[ Idx*4], rgba[ Idx*4+1 ], rgba[ Idx*4+2 ] );

			int I;
			I = Idx-1;  if( x > 0  && imgFlg [ I ] == 0 ) { imgFlg[I] = -2; boundPix.insert(  make_pair( colorDist( regions[r].meanCol, rgba, I*4 ), PixInfo( x-1,y  , I) ) ); } 
			I = Idx+1;  if( x <W-1 && imgFlg [ I ] == 0 ) { imgFlg[I] = -2; boundPix.insert(  make_pair( colorDist( regions[r].meanCol, rgba, I*4 ), PixInfo( x+1,y  , I) ) ); } 
			I = Idx-W;  if( y > 0  && imgFlg [ I ] == 0 ) { imgFlg[I] = -2; boundPix.insert(  make_pair( colorDist( regions[r].meanCol, rgba, I*4 ), PixInfo( x  ,y-1, I) ) ); } 
			I = Idx+W;  if( y <W-1 && imgFlg [ I ] == 0 ) { imgFlg[I] = -2; boundPix.insert(  make_pair( colorDist( regions[r].meanCol, rgba, I*4 ), PixInfo( x  ,y+1, I) ) ); } 
		}
	}


	int c = 0;

	while( !boundPix.empty() )
	{
		const int x   = boundPix.begin()->second.x  ;
		const int y   = boundPix.begin()->second.y  ;
		const int idx = boundPix.begin()->second.idx;
		boundPix.erase( boundPix.begin() );


		//8�ߖT������A�قȂ�̈�ɐڂ��Ă��邩���ׂ�
		int I;
		set<int> NeiRegions;
		I = idx-1-W; if( x > 0  && y > 0  && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx  -W; if(           y > 0  && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx+1-W; if( x <W-1 && y > 0  && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx-1  ; if( x > 0  &&           imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx+1  ; if( x <W-1 &&           imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx-1+W; if( x > 0  && y <H-1 && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx  +W; if(           y <H-1 && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );
		I = idx+1+W; if( x <W-1 && y <H-1 && imgFlg[I] > 0 ) NeiRegions.insert( imgFlg[I] );


		if(      NeiRegions.size() >  1 ) imgFlg[ idx ] = -1;
		else if( NeiRegions.size() == 0 ) fprintf( stderr, "never come here\n");
		else
		{
			//���̉�f�𐬒�������
			int regionID = *(NeiRegions.begin());
			imgFlg[ idx ] = regionID;
			regions[regionID-1].addPixel( rgba[4*idx], rgba[4*idx + 1], rgba[4*idx + 2] );

			int I;
			I = idx-1-W; if( x > 0  && y > 0  && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x-1,y-1, I) ) );}
			I = idx  -W; if(           y > 0  && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x  ,y-1, I) ) );}
			I = idx+1-W; if( x <W-1 && y > 0  && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x+1,y-1, I) ) );}
			I = idx-1  ; if( x > 0  &&           imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x-1,y  , I) ) );}
			I = idx+1  ; if( x <W-1 &&           imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x+1,y  , I) ) );}
			I = idx-1+W; if( x > 0  && y <H-1 && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x-1,y+1, I) ) );}
			I = idx  +W; if(           y <H-1 && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x  ,y+1, I) ) );}
			I = idx+1+W; if( x <W-1 && y <H-1 && imgFlg[I]== 0 ) {imgFlg[I] = -2;  boundPix.insert( make_pair( colorDist( regions[regionID-1].meanCol, rgba, I*4 ), PixInfo( x+1,y+1, I) ) );}
		}

		++c;
		if( c% 400 ==0) //�����p���[�`��
		{
			memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
			for( int i=0; i< WH; ++i) {
				if( imgFlg[i] <= 0 ) m_imgDisp.setColor( i*4, 0,0,255);
				else                 m_imgDisp.setColor( i*4, regions[ imgFlg[ i ] - 1 ].meanCol );
			}
			m_imgDisp.unbind( &m_ogl );
			m_ogl.RedrawWindow();
		}
	}


	double PIX_R = m_imgRectW / (double)W;
	m_boundLines.clear(); 
	for( int y=0; y<H-1; ++y )
	for( int x=0; x<W-1; ++x ){
		int i = x + y * W;
		if( imgFlg[i] * imgFlg[i+1] < 0 ) m_boundLines.push_back( TLineSegm( (x+1)*PIX_R, (x+1)*PIX_R,  y   *PIX_R, (y+1)*PIX_R) );
		if( imgFlg[i] * imgFlg[i+W] < 0 ) m_boundLines.push_back( TLineSegm(   x  *PIX_R, (x+1)*PIX_R, (y+1)*PIX_R, (y+1)*PIX_R) );
	}

	memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
	for( int i=0; i< WH; ++i) {
		if( imgFlg[i] <= 0 ) m_imgDisp.setColor(i*4, 0,0,255);
		else                 m_imgDisp.setColor( i*4, regions[ imgFlg[ i ] - 1 ].meanCol );
	}
	m_imgDisp.unbind( &m_ogl );
	m_ogl.RedrawWindow();

	delete[] imgFlg;
}








////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
//watershed segmentation




//byte *sobelX, byte sobelY should be allocated before
//color [0,255]-->[0,1]
static void t_sobel( const byte *rgba, const int W, const int H, double *sobelX, double *sobelY)
{
	double filterX[3][3]={	{-1,  0,  1}, {-2,  0,  2}, {-1,  0,  1}};
	double filterY[3][3]={  {-1, -2, -1}, { 0,  0,  0}, { 1,  2,  1}};

	for(int y = 0, idx=0; y < H ; y++)
	for(int x = 0       ; x < W ; x++, ++idx)
	{
		double vx = 0, vy = 0 ;		
		for( int wy = -1; wy < 2; ++wy)
		for( int wx = -1; wx < 2; ++wx)
		{
			int pixId = 4*( idx + wx + wy * W );
			double pixVal;
			if( x + wx < 0 || x + wx > W-1 || y + wy < 0 || y + wy > H-1 ) pixVal = 0;
			else pixVal	= (rgba[ pixId + 0] + rgba[ pixId + 1] + rgba[ pixId + 2] ) * 0.33333 / 255.0;
			vx += filterX[wy+1][wx+1] * pixVal;
			vy += filterY[wy+1][wx+1] * pixVal;
		}
		sobelX[ idx ] = fabs( vx ) ;
		sobelY[ idx ] = fabs( vy ) ;
	}
}





//watershed pixel (watershed segmentation�̋��Epixel) ���ߖT�̗̈�Ɋ֘A�t����
static void t_collapseWsdPixel( const int W, const int H, const byte *imgRGBA, int *pix_wsdLabel)
{
	const int WH = W*H;

	//����color�v�Z
	int maxLabel = 0;
	for( int i=0; i < WH; ++i) maxLabel = max( maxLabel, pix_wsdLabel[i] );

	vector< TVector3 > labelColor( maxLabel+1    );
	vector< int      > labelNum  ( maxLabel+1, 0 );

	for( int i = 0; i < WH; ++i){
		labelColor[ pix_wsdLabel[i] ] += TVector3( imgRGBA[4*i  ], imgRGBA[4*i+1], imgRGBA[4*i+2]);
		labelNum  [ pix_wsdLabel[i] ] += 1;
	}
	for( int i = 0; i < maxLabel+1; ++i){
		labelColor[ i ] /= labelNum[i];
	}

	//watershed pixel (�l0)���ߖT�̗̈�Ɋ֘A�Â���
	for( int y = 0; y < H; ++y)	
	for( int x = 0; x < W; ++x) if( pix_wsdLabel[ x + y*W ] == 0 )
	{	
		const int idx = x + y*W;
		double colDiff = DBL_MAX;
		for( int c = 0; c<4; ++c)
		{
			int neiIdx = 0;
			if     ( c == 0 && x >   0	) neiIdx = idx - 1    ;//��
			else if( c == 1 && x < W-1	) neiIdx = idx + 1    ;//�E
			else if( c == 2 && y >   0	) neiIdx = idx - W    ;//��
			else if( c == 3 && y < H-1  ) neiIdx = idx + W    ;//��
			else continue;

			if( pix_wsdLabel[ neiIdx ] > 0 )
			{
				double r = labelColor[ pix_wsdLabel[ neiIdx ] ].data[0];
				double g = labelColor[ pix_wsdLabel[ neiIdx ] ].data[1];
				double b = labelColor[ pix_wsdLabel[ neiIdx ] ].data[2];
				double d =   (imgRGBA[ idx*4   ] - r)*(imgRGBA[ idx*4   ] - r)
						    +(imgRGBA[ idx*4+1 ] - g)*(imgRGBA[ idx*4+1 ] - g)
							+(imgRGBA[ idx*4+2 ] - b)*(imgRGBA[ idx*4+2 ] - b);

				if( d < colDiff )
				{ 
					colDiff = d; 
					pix_wsdLabel[idx] = pix_wsdLabel[ neiIdx ];
				}
			}
		}
	}
}




void TCore::runWatershedSegmentation()
{
	const int   W    = m_imgOrig.m_width  ;
	const int   H    = m_imgOrig.m_height, WH = W*H ;	
	const byte *rgba = m_imgOrig.m_RGBA   ;
	
	//(1)sobel----------------------------------------------------
	double *sobelX   = new double[ WH ];
	double *sobelY   = new double[ WH ];
	byte   *gradMag  = new byte  [ WH ];

	memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
	m_imgDisp.gaussianFilter33();
	m_imgDisp.gaussianFilter33();

	t_sobel( m_imgDisp.m_RGBA, W, H, sobelX, sobelY);
	double maxVal = - DBL_MAX;
	for( int i=0; i<WH; ++i) maxVal     = max( maxVal,  sqrt( sobelX[i]*sobelX[i] + sobelY[i]*sobelY[i])          );
	for( int i=0; i<WH; ++i) gradMag[i] = (byte)( 255 * sqrt( sobelX[i]*sobelX[i] + sobelY[i]*sobelY[i]) / maxVal );



	//(2)watershed 
	int *pix_wsdLabel = new int[WH];
	TWatershed2DEx    ( W, H, gradMag         , pix_wsdLabel); //�epixel�Ƀ��x���������� ���x���l0�͋��E (watershed pixel�ƌĂ΂��)
	t_collapseWsdPixel( W, H, m_imgOrig.m_RGBA, pix_wsdLabel); //���Epixel�� �F�̋߂��ߖT�̈�ɗZ��������
	for( int i=0; i < WH; ++i) --pix_wsdLabel[i];

	//(3)watershed region�̕��ϐF���v�Z
	int wsdMaxLabel = 0;
	for( int i=0; i < WH; ++i) wsdMaxLabel = max( wsdMaxLabel, pix_wsdLabel[i] );
	vector< TRegionInfo > regions( wsdMaxLabel + 1);

	for( int i = 0; i < WH ; ++i) regions[ pix_wsdLabel[i] ].addPixel( m_imgOrig.m_RGBA[4*i  ], m_imgOrig.m_RGBA[4*i+1], m_imgOrig.m_RGBA[4*i+2] );


	double PIX_R = m_imgRectW / (double)W;
	m_boundLines.clear(); 
	for( int y=0; y<H-1; ++y )
	for( int x=0; x<W-1; ++x ){
		int i = x + y * W;
		if( pix_wsdLabel[i] != pix_wsdLabel[i+1] ) m_boundLines.push_back( TLineSegm( (x+1)*PIX_R, (x+1)*PIX_R,  y   *PIX_R, (y+1)*PIX_R) );
		if( pix_wsdLabel[i] != pix_wsdLabel[i+W] ) m_boundLines.push_back( TLineSegm(   x  *PIX_R, (x+1)*PIX_R, (y+1)*PIX_R, (y+1)*PIX_R) );
	}

	memcpy( m_imgDisp.m_RGBA, m_imgOrig.m_RGBA, sizeof( byte ) * 4*W*H );
	for( int i=0; i< WH; ++i) m_imgDisp.setColor( i*4, regions[ pix_wsdLabel[ i ] ].meanCol );
	m_imgDisp.unbind( &m_ogl );
	m_ogl.RedrawWindow();

	delete[] pix_wsdLabel;
	delete[] sobelX ;
	delete[] sobelY ;
	delete[] gradMag;
}