// TDlgImageProc.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "TImageProcess.h"
#include "TDlgImageProc.h"
#include "afxdialogex.h"
#include "TCore.h"


// TDlgImageProc �_�C�A���O

IMPLEMENT_DYNAMIC(TDlgImageProc, CDialogEx)

TDlgImageProc::TDlgImageProc(CWnd* pParent /*=NULL*/)
	: CDialogEx(TDlgImageProc::IDD, pParent)
{

}

TDlgImageProc::~TDlgImageProc()
{
}

void TDlgImageProc::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_1, m_slider_1);
}


BEGIN_MESSAGE_MAP(TDlgImageProc, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_REGIONGROW, &TDlgImageProc::OnBnClickedButtonRegiongrow)
	ON_BN_CLICKED(IDC_BUTTON_REGIONGROW_MULTI, &TDlgImageProc::OnBnClickedButtonRegiongrowMulti)
	ON_BN_CLICKED(IDC_BUTTON_WATERSHED, &TDlgImageProc::OnBnClickedButtonWatershed)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()


// TDlgImageProc ���b�Z�[�W �n���h���[


BOOL TDlgImageProc::PreTranslateMessage(MSG* pMsg)
{
	if( WM_KEYDOWN == pMsg->message )
	{
		switch( pMsg->wParam )
		{
			case VK_RETURN:
				return FALSE;
			case VK_ESCAPE:
				return FALSE;
			default:
				break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL TDlgImageProc::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//����{�^���̖�����//
    CMenu*  pMenu = GetSystemMenu(FALSE);
    pMenu->EnableMenuItem(SC_CLOSE, MF_GRAYED);

	m_slider_1.SetRange( 0, 255 );
	m_slider_1.SetPos  ( 40     );

	CString str; str.Format("%d", m_slider_1.GetPos());
	((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ��O : OCX �v���p�e�B �y�[�W�͕K�� FALSE ��Ԃ��܂��B
}


void TDlgImageProc::OnBnClickedButtonRegiongrow()
{
	TCore::getInst()->runRegionGrowing( m_slider_1.GetPos() );
}


void TDlgImageProc::OnBnClickedButtonRegiongrowMulti()
{
	TCore::getInst()->runRegionGrowing_multiRegion();
}


void TDlgImageProc::OnBnClickedButtonWatershed()
{
	TCore::getInst()->runWatershedSegmentation();
}


void TDlgImageProc::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if( *pScrollBar == m_slider_1)
	{
		CString str; str.Format("%d", m_slider_1.GetPos());
		((CEdit*)GetDlgItem( IDC_EDIT_1))->SetWindowTextA(str);
	}
	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}
