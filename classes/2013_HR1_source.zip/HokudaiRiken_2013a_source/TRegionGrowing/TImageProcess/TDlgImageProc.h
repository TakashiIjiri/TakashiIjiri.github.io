#pragma once


// TDlgImageProc �_�C�A���O
#include "resource.h"
#include "afxcmn.h"

class TDlgImageProc : public CDialogEx
{
	DECLARE_DYNAMIC(TDlgImageProc)

public:
	TDlgImageProc(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~TDlgImageProc();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DIALOG_IMGPRC };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonRegiongrow();
	afx_msg void OnBnClickedButtonRegiongrowMulti();
	afx_msg void OnBnClickedButtonWatershed();
	CSliderCtrl m_slider_1;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
