
// TImageProcessView.cpp : CTImageProcessView �N���X�̎���
//

#include "stdafx.h"
// SHARED_HANDLERS �́A�v���r���[�A�T���l�C���A����ь����t�B���^�[ �n���h���[���������Ă��� ATL �v���W�F�N�g�Œ�`�ł��A
// ���̃v���W�F�N�g�Ƃ̃h�L�������g �R�[�h�̋��L���\�ɂ��܂��B
#ifndef SHARED_HANDLERS
#include "TImageProcess.h"
#endif

#include "TImageProcessDoc.h"
#include "TImageProcessView.h"
#include "TCore.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#endif






// CTImageProcessView

IMPLEMENT_DYNCREATE(CTImageProcessView, CView)

BEGIN_MESSAGE_MAP(CTImageProcessView, CView)
	// �W������R�}���h
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MBUTTONDBLCLK()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_RBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_MOVE()
END_MESSAGE_MAP()

// CTImageProcessView �R���X�g���N�V����/�f�X�g���N�V����

CTImageProcessView::CTImageProcessView()
{
}
CTImageProcessView::~CTImageProcessView()
{
}

BOOL CTImageProcessView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}


BOOL CTImageProcessView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// ����̈������
	return DoPreparePrinting(pInfo);
}

void CTImageProcessView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CTImageProcessView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}


// CTImageProcessView �f�f

#ifdef _DEBUG
void CTImageProcessView::AssertValid() const
{
	CView::AssertValid();
}

void CTImageProcessView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTImageProcessDoc* CTImageProcessView::GetDocument() const // �f�o�b�O�ȊO�̃o�[�W�����̓C�����C���ł��B
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTImageProcessDoc)));
	return (CTImageProcessDoc*)m_pDocument;
}
#endif //_DEBUG


// CTImageProcessView ���b�Z�[�W �n���h���[


int CTImageProcessView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1) return -1;
	TCore::getInst()->m_ogl.OnCreate( this );
	return 0;
}
void CTImageProcessView::OnDestroy()
{
	CView::OnDestroy();
	TCore::getInst()->m_ogl.OnDestroy();
}

void CTImageProcessView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	TCore::getInst()->m_ogl.OnSize(cx,cy);


}


BOOL CTImageProcessView::OnEraseBkgnd(CDC* pDC)
{
	return true; // return CView::OnEraseBkgnd(pDC);
}

void CTImageProcessView::OnDraw(CDC* /*pDC*/)
{
	CTImageProcessDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc) return;

	double rectW = TCore::getInst()->m_imgRectW;
	double rectH = TCore::getInst()->m_imgRectH;

	TCore::getInst()->m_ogl.OnDraw_Begin(7.5, 0, 0.5*rectH );

	glPushMatrix();

	TCore::getInst()->drawScene();

	glPopMatrix();
	TCore::getInst()->m_ogl.OnDraw_End  ();
}












void CTImageProcessView::OnLButtonDblClk(UINT nFlags, CPoint point){}
void CTImageProcessView::OnMButtonDblClk(UINT nFlags, CPoint point){}
void CTImageProcessView::OnRButtonDblClk(UINT nFlags, CPoint point){}






void CTImageProcessView::OnLButtonDown(UINT nFlags, CPoint point){
}


void CTImageProcessView::OnLButtonUp(UINT nFlags, CPoint point){
}

void CTImageProcessView::OnMButtonDown(UINT nFlags, CPoint point)
{
}
void CTImageProcessView::OnMButtonUp(UINT nFlags, CPoint point)
{
}

void CTImageProcessView::OnRButtonDown(UINT nFlags, CPoint point)
{
}
void CTImageProcessView::OnRButtonUp(UINT nFlags, CPoint point)
{
}





void CTImageProcessView::OnMouseMove(UINT nFlags, CPoint point)
{

}


BOOL CTImageProcessView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt){
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}






void CTImageProcessView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags){}






void CTImageProcessView::OnMove(int x, int y)
{

}
