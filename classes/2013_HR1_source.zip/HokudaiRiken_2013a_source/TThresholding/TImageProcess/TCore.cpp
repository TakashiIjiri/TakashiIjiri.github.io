#include "StdAfx.h"
#include "TCore.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#endif




TCore::~TCore(void){}

TCore::TCore(void)
{
	//load image
	CString         filter("bmp Files (*.bmp;*.bmp)|*.bmp; *.bmp||");
	CFileDialog     selDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, filter);
	bool inverted;
	if (selDlg.DoModal() == IDOK) m_imgOrig.allocateFromFile( selDlg.GetPathName(), inverted, &m_ogl );
	else exit(1);
	if( inverted ) m_imgOrig.flipImageInY();

	//�T�C�Y�擾
	const int W = m_imgOrig.m_width ;
	const int H = m_imgOrig.m_height;
	const int WH = W*H;
	m_imgRectW = 7.0;
	m_imgRectH = 7.0 / (double) W * H;

	//�O���[�X�P�[���ϊ�
	for( int i = 0; i < WH; ++i)
	{
		double c = m_imgOrig.m_RGBA[4*i] + m_imgOrig.m_RGBA[4*i+1] + m_imgOrig.m_RGBA[4*i+2];
		c *= 0.33333333;
		m_imgOrig.m_RGBA[4*i] = m_imgOrig.m_RGBA[4*i+1] = m_imgOrig.m_RGBA[4*i+2] = (byte) c;
	}

	m_imgDisp.allocateImage( m_imgOrig, 0 ); 
	m_imgDisp.m_DoInterpolation = false;
	m_imgOrig.m_DoInterpolation = false;

	m_dlg.Create( IDD_DIALOG_IMGPRC );
	m_dlg.ShowWindow( SW_SHOW );

	//�q�X�g�O�����v�Z
	memset( m_Histgram, 0, sizeof( int )* 256 );
	for( int i = 0; i < WH ; ++i) m_Histgram[m_imgOrig.m_RGBA[4*i]]++;

	int histMax = 0;
	for( int i = 1; i < 255; ++i) histMax = max( histMax, m_Histgram[i]); //�ő�l�����̍ۂɁA�l0�ƒl255�͖���
	for( int i = 0; i < 256; ++i) m_Histgram_normalized[i] = m_Histgram[i] / (double) histMax;


}




static void drawImage( const double rectW, const double rectH, TOGL2DImage &img)
{
	glDisable( GL_LIGHTING  );
	glDisable( GL_CULL_FACE );
	glColor3d( 1,1,1        );
	glEnable( GL_TEXTURE_2D );
	img.bind(0);
	glBegin  ( GL_QUADS     );
	glTexCoord2d(0,0); glVertex3d(     0,    0, 0 );
	glTexCoord2d(1,0); glVertex3d( rectW,    0, 0 );
	glTexCoord2d(1,1); glVertex3d( rectW,rectH, 0 );
	glTexCoord2d(0,1); glVertex3d(     0,rectH, 0 );
	glEnd( );
	glDisable( GL_TEXTURE_2D );
}





void TCore::drawScene()
{
	const int W = m_imgOrig.m_width  ;
	const int H = m_imgOrig.m_height ;	
	glDisable( GL_LIGHTING );

	glPushMatrix();
		glTranslated( - m_imgRectW - 0.1, 0, 0); drawImage( m_imgRectW, m_imgRectH, m_imgOrig   );
		glTranslated(   m_imgRectW + 0.1, 0, 0); drawImage( m_imgRectW, m_imgRectH, m_imgDisp   );
	glPopMatrix();
}









void TCore::thresholding( byte thresh )
{
	const int W = m_imgOrig.m_width ;
	const int H = m_imgOrig.m_height;
	const int WH = W*H;

	for( int i = 0; i < WH; ++i)
		m_imgDisp.m_RGBA[4*i] = m_imgDisp.m_RGBA[4*i+1] = m_imgDisp.m_RGBA[4*i+2] = m_imgOrig.m_RGBA[4*i] >= thresh ? 255 : 0;
	m_imgDisp.unbind( &m_ogl );
}


static byte OtsuMethod( const int *hist)
{
	double maxVal = -1;
	double thresh = 0 ;

	for( int i=1; i < 255; ++i)
	{
		//�ǂ݂₷���d���ŏ���
		double w1 = 0, w2 = 0;//��f�� (int�Ŏ���integer�̌��E�𓥂݉z����̂�double) 
		double m1 = 0, m2 = 0;//����
		double s1 = 0, s2 = 0;//���U

		for( int k = 0; k < i  ; ++k) w1 += hist[k]               ;  
		for( int k = 0; k < i  ; ++k) m1 += hist[k] * k           ;  m1 /= w1;
		for( int k = 0; k < i  ; ++k) s1 += hist[k] *(k-m1)*(k-m1);  s1 /= w1;
		for( int k = i; k < 256; ++k) w2 += hist[k]               ;
		for( int k = i; k < 256; ++k) m2 += hist[k] * k           ;  m2 /= w2;
		for( int k = i; k < 256; ++k) s2 += hist[k] *(k-m2)*(k-m2);  s2 /= w2;

		double S =  w1 * w2 * (m1-m2)*(m1-m2);// ( (w1+w2)*(w1+w2) );

		if( S > maxVal ) 
		{
			maxVal = S;
			thresh = i;
		}
	}
	return (byte)thresh;

}



byte TCore::calcOtsuThresh(){
	return OtsuMethod( m_Histgram );
}


void TCore::calcOtsu_LocalWindow()
{
	const int W     = m_imgOrig.m_width ;
	const int H     = m_imgOrig.m_height;
	const int WH    = W*H;
	const int wSize = 20;

#pragma omp parallel for
	for( int y = 0; y < H; ++y)
	{
		for( int x = 0; x < W; ++x)
		{
			int hist[256];
			memset( hist, 0, sizeof( int ) * 256 );

			//compute local histgram;
			for( int yy = y - wSize; yy <= y + wSize; ++yy) if( 0 <= yy && yy <= H-1 )
			for( int xx = x - wSize; xx <= x + wSize; ++xx) if( 0 <= xx && xx <= W-1 ) hist[ m_imgOrig.m_RGBA[ 4*(yy*W + xx) ] ] ++;

			int i = 4*(x + W*y);
			byte t = OtsuMethod( hist );
			m_imgDisp.m_RGBA[i] = m_imgDisp.m_RGBA[i+1] = m_imgDisp.m_RGBA[i+2] = m_imgOrig.m_RGBA[i] >= t ? 255 : 0; 
			if( (y*W+x)  % 1000 ==0 ) fprintf( stderr, "*");
		}
	}
	fprintf( stderr, "DONE");
	m_imgDisp.unbind( &m_ogl );

}




void TCore::calcSouvola_LocalWindow()
{
	const int    R  = 128;
	const double K  = 0.2;

	const int W     = m_imgOrig.m_width ;
	const int H     = m_imgOrig.m_height;
	const int WH    = W*H;
	const int wSize = 20;

#pragma omp parallel for
	for( int y = 0; y < H; ++y)
	{
		for( int x = 0; x < W; ++x)
		{
			int hist[256];
			memset( hist, 0, sizeof( int ) * 256 );
			
			//compute local histgram;
			for( int yy = y - wSize; yy <= y + wSize; ++yy) if( 0 <= yy && yy <= H-1 )
			for( int xx = x - wSize; xx <= x + wSize; ++xx) if( 0 <= xx && xx <= W-1 ) hist[ m_imgOrig.m_RGBA[ 4*(yy*W + xx) ] ] ++;

			//�ǂ݂₷���d���ŏ���
			double w  = 0; for( int k = 0; k < 256; ++k) w += hist[k]             ;         //��f��
			double m  = 0; for( int k = 0; k < 256; ++k) m += hist[k] * k         ;  m /= w;//����
			double s  = 0; for( int k = 0; k < 256; ++k) s += hist[k] *(k-m)*(k-m);  s /= w; s = sqrt( s );//���U
			
			byte t = (byte)( m * (1 + K * (s / R - 1)) );


			int i = 4*(x + W*y);
			m_imgDisp.m_RGBA[i] = m_imgDisp.m_RGBA[i+1] = m_imgDisp.m_RGBA[i+2] = m_imgOrig.m_RGBA[i] >= t ? 255 : 0; 
			if( (y*W+x)  % 1000 ==0 ) fprintf( stderr, "*");
		}
	}
	fprintf( stderr, "DONE");
	m_imgDisp.unbind( &m_ogl );
}
