#pragma once

#include "resource.h"
#include "afxcmn.h"

// TDlgImgProc �_�C�A���O

class TDlgImgProc : public CDialogEx
{
	DECLARE_DYNAMIC(TDlgImgProc)

public:
	TDlgImgProc(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~TDlgImgProc();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DIALOG_IMGPRC };


	int m_currentThresh;
	int m_pcW, m_pcH;
	HBITMAP m_bmp    ; //double buffering�pbmp
	byte   *m_bmpBits; //double buffering�pbmp�̒��g��bit 

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	CSliderCtrl m_slider_thresh;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBnClickedButtonOtsu();
	afx_msg void OnBnClickedButtonOtsuLocal();
	afx_msg void OnBnClickedButtonSauvolaLocal();
};
