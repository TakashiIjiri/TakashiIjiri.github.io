// TDlgImgProc.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "TImageProcess.h"
#include "TDlgImgProc.h"
#include "afxdialogex.h"
#include "TCore.h"


// TDlgImgProc �_�C�A���O

IMPLEMENT_DYNAMIC(TDlgImgProc, CDialogEx)

TDlgImgProc::TDlgImgProc(CWnd* pParent /*=NULL*/)
	: CDialogEx(TDlgImgProc::IDD, pParent)
{
	m_currentThresh = 0;
}

TDlgImgProc::~TDlgImgProc()
{
	DeleteObject( m_bmp );
}

void TDlgImgProc::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_THRESHOLD, m_slider_thresh);
}


BEGIN_MESSAGE_MAP(TDlgImgProc, CDialogEx)
	ON_WM_HSCROLL()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDC_BUTTON_OTSU, &TDlgImgProc::OnBnClickedButtonOtsu)
	ON_BN_CLICKED(IDC_BUTTON_OTSU_LOCAL, &TDlgImgProc::OnBnClickedButtonOtsuLocal)
	ON_BN_CLICKED(IDC_BUTTON_SAUVOLA_LOCAL, &TDlgImgProc::OnBnClickedButtonSauvolaLocal)
END_MESSAGE_MAP()


// TDlgImgProc ���b�Z�[�W �n���h���[


BOOL TDlgImgProc::PreTranslateMessage(MSG* pMsg)
{
	if( WM_KEYDOWN == pMsg->message )
	{
		switch( pMsg->wParam )
		{
			case VK_RETURN:
				return FALSE;
			case VK_ESCAPE:
				return FALSE;
			default:
				break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL TDlgImgProc::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//����{�^���̖�����//
    CMenu*  pMenu = GetSystemMenu(FALSE);
    pMenu->EnableMenuItem(SC_CLOSE, MF_GRAYED);
	m_slider_thresh.SetRange( 0, 255 );
	m_slider_thresh.SetPos  ( 128    );

	
	//double buffering�p��bmp����
	CWnd *pc = GetDlgItem(IDC_PC_HISTOGRAM );  

	WINDOWPLACEMENT w; pc->GetWindowPlacement( &w );  
	m_pcW = w.rcNormalPosition.right  - w.rcNormalPosition.left;
	m_pcH = w.rcNormalPosition.bottom - w.rcNormalPosition.top ;

	BITMAPINFO binfo;
	ZeroMemory( &binfo, sizeof(binfo));
	binfo.bmiHeader.biSize     = sizeof(BITMAPINFOHEADER);
	binfo.bmiHeader.biBitCount = 32;
	binfo.bmiHeader.biPlanes   =  1;
	binfo.bmiHeader.biWidth    =  m_pcW;
	binfo.bmiHeader.biHeight   =  m_pcH; //���ɂ����top down�ɂȂ�

	m_bmp = CreateDIBSection( NULL, &binfo, DIB_RGB_COLORS, (void **)(&m_bmpBits), NULL, 0); // pc1 pc2 pc3�̃T�C�Y�͓������Ƃ���

	return TRUE;  // return TRUE unless you set the focus to a control
}


void TDlgImgProc::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{

	if( *pScrollBar == m_slider_thresh )
	{
		m_currentThresh = m_slider_thresh.GetPos();
		CString str;
		str.Format("%d", m_currentThresh );
		((CEdit*)GetDlgItem( IDC_EDIT_THRESH))->SetWindowTextA(str);

		TCore::getInst()->thresholding( m_currentThresh );
		TCore::getInst()->m_ogl.RedrawWindow();
		Invalidate(FALSE); 
		UpdateWindow();
	}

	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}






void TDlgImgProc::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	//�y��������
	CPen pen_R; pen_R.CreatePen( PS_SOLID, 2, RGB(0xFF,0x00,0x00) );
	CPen pen_G; pen_G.CreatePen( PS_SOLID, 2, RGB(0x00,0xFF,0x00) );


	//�_�u���o�b�t�@�����O�p��Bitmap��CDC���擾...
	CWnd    *pc   = GetDlgItem( IDC_PC_HISTOGRAM ); 
	CDC     *pcDC = pc->GetDC();
	CBitmap *cbmp = CBitmap::FromHandle( m_bmp );

	CDC bitmapDC; 
	bitmapDC.CreateCompatibleDC( &dc );
	CBitmap *oldBmp = bitmapDC.SelectObject( cbmp ); //�����ȍ~�ł� bitmap�� �|�C���^����� bitmapDC������A�N�Z�X�ł���悤�ɂȂ��Ă���

	//bitmapDC�ɏ�������
	bitmapDC.FillSolidRect( 0,0, m_pcW, m_pcH, 0xffffff );
	CPen *oldPen = bitmapDC.SelectObject( &pen_G);

	double *hist = TCore::getInst()->m_Histgram_normalized;
	for( int i=0; i < m_pcW; ++i)
	{
		int x = (int)(  (double)i / (double)m_pcW * 255.0);
		bitmapDC.MoveTo( i, m_pcH);
		bitmapDC.LineTo( i, m_pcH - (int)( hist[x]*m_pcH));
	}
	
	bitmapDC.SelectObject( &pen_R);
	bitmapDC.MoveTo( (int)(m_currentThresh / 256.0 * m_pcW), 0);
	bitmapDC.LineTo( (int)(m_currentThresh / 256.0 * m_pcW), m_pcH);

	//bitmap��Picture Control�ɃR�s�[
	pcDC->BitBlt( 1,1, m_pcW-2, m_pcH-2, &bitmapDC, 0,0,SRCCOPY);//double buffering


	//��������̂�j��
	bitmapDC.SelectObject( oldPen );
	bitmapDC.SelectObject( oldBmp );
	DeleteDC( bitmapDC );
	DeleteObject( pen_R );
	DeleteObject( pen_G );

}


BOOL TDlgImgProc::OnEraseBkgnd(CDC* pDC)
{
	return CDialogEx::OnEraseBkgnd(pDC);
}


void TDlgImgProc::OnBnClickedButtonOtsu()
{
	m_currentThresh = TCore::getInst()->calcOtsuThresh();
	
	CString str;
	str.Format("%d", m_currentThresh );
	((CEdit*)GetDlgItem( IDC_EDIT_THRESH))->SetWindowTextA(str);
	m_slider_thresh.SetPos( m_currentThresh );
	TCore::getInst()->thresholding( m_currentThresh );
	TCore::getInst()->m_ogl.RedrawWindow();
	Invalidate(FALSE); 
	UpdateWindow();	
}


void TDlgImgProc::OnBnClickedButtonOtsuLocal()
{
	TCore::getInst()->calcOtsu_LocalWindow();
	TCore::getInst()->m_ogl.RedrawWindow();
}


void TDlgImgProc::OnBnClickedButtonSauvolaLocal()
{
	TCore::getInst()->calcSouvola_LocalWindow();
	TCore::getInst()->m_ogl.RedrawWindow();
}
