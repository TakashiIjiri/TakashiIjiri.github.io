import numpy as np

A = np.array([5,6,7,8])
B = np.array([1,2,3,4])
print(A, A.shape)
print(B, B.shape)
# 要素がひとつのタプルにはカンマがつく (4, )
# タプルはそもそもカンマで区切られた値なので
# a = 1,2,3  #← 丸かっこを省略することも可能
# a = 3,     #← これタプルになるので注意


#要素ごとの演算(和差積商余べき)
C = A + B
D = A - B
E = A * B
F = A / B
G = A % B
H = A ** B
I = A + 3  #スカラーとの和

#2D
A=np.array([[1,2,3],[4,5,6]])
B=np.array([[1,2,3],[4,5,6]])
C=A+B
print(C, C.shape)
