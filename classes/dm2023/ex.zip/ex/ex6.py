import numpy as np

A    = np.array([1,2,3,4,5,6,7,8])
mean = np.mean( A ) #全要素の平均
sum  = np.sum ( A ) #全要素の総和
vari = np.var ( A ) #全要素の分散
print( mean, sum, vari)

#分散は以下の方法でも計算可能
A = A-mean # 全要素からmeanを引く
A = A**2   # 全要素を二乗
print( np.sum(A)/A.shape[0])


#np.arrayの初期化方法
A = np.array([1,2,3,4]) #listで初期化
B = np.array((1,2,3,4)) #tupleで初期化
C = np.zeros(3)         #要素数指定, 要素は0
D = np.ones(3)          #要素数指定, 要素は1
E = np.ones((2,3))      #[[1,1,1][1,1,1]]
F = np.zeros_like(E)    #Eと同じサイズの0配列
F = np.identity(3)      #3x3 単位行列


a = [1,2,3]
b = a
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))


a = np.array([1,2,3])
b = a
b = np.copy(a)
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))
