import numpy as np
import cv2

#load image
img = cv2.imread("img.png")
img = np.float64( img ) #要素をfloat型に
H   = img.shape[0]
W   = img.shape[1]

img_gry = np.zeros( (H,W), float ) #空の画像(WxH)を用意

for y in range(H) :
    for x in range(W) :
        r = img[y,x,2] #画素(y,x)のred値
        g = img[y,x,1] #画素(y,x)のgreen値
        b = img[y,x,0] #画素(y,x)のblue値
        img_gry[y,x] = r #red値を代入

#display img
cv2.imshow("gray  image", np.uint8( img_gry) )
cv2.waitKey(0)
