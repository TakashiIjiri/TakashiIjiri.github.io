
print('hello, world')
