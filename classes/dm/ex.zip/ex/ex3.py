# ex3.py
# 実行例 : python ex3.py arg1 arg2 5
import sys

a1 = sys.argv[1]
a2 = sys.argv[2]
a3 = sys.argv[3]
print(a1, a2, a3)
