# ex6_ref.py : 配列の変数は参照を保持する
import numpy as np

# (1) list : aとbは同じものを指す
a = [1,2,3]
b = a
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))

# (2) np.array : aとbは同じものを指す
#     b = np.copy(a) とするとコピーが生成され，aとbは別物になる
a = np.array([1,2,3])
b = a
# b = np.copy(a)
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))

# (3) pythonの変数はオブジェクトへの参照を保持する
#aは 値1を持つ int値 オブジェクトを指す
#bも aが参照する int値オブジェクトを指す
a = 1
b = a
print(a, id(a)) # aとbは同じものを参照
print(b, id(b)) # aとbは同じものを参照

# ここが問題
b = 3
# 数値オブジェクトはimmutable (不変)なので変更は起きない
# 新しいint値オブジェクトが生成されbはそれを指す
print(a, id(a)) # aとbは違うものを指す
print(b, id(b))
