import numpy as np

def func(a,b) :
    print("a is ", a)
    print("b is ", b)
    wa = a+b
    sa = a-b
    return wa, sa


if __name__ == '__main__':
	sum, sub = func(1,2)
	print( sum, sub)
