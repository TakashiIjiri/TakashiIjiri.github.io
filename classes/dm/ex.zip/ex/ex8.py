import numpy as np

A = [1, 2, 4, 2, 1, 1, 3, 4]

for p in A :
    if p == 1 or p < 10:
        print( "a" )
    elif p == 2:
        print( "b" )
    else:
        print( "c" )
