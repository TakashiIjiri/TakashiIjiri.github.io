import numpy as np

def func(a,b) :
    print("a is ", a)
    print("b is ", b)
    #print("c is ", c) #外のcを参照できる

    wa = a+b
    sa = a-b
    seki = a*b
    return wa, sa, seki

a = 2
b = 5
#c = 100
sum, sub, seki = func(a,b)

print( a,b, sum, sub, seki)
