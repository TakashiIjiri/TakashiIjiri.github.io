# ex9.py
import numpy as np

def func(a, b):
    print('a is ', a)
    print('b is ', b)
    wa = a+b
    sa = a-b
    return wa, sa

a = 1
b = 2
sum, sub = func(a,b)

print( a,b, sum, sub)
