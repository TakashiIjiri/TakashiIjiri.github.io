#
#
import glob
import time
import hashlib


if __name__ == '__main__':

    key = str(time.time())
    hashval = hashlib.sha256(key.encode()).hexdigest()

    path = []
    path.extend(glob.glob("day1/exer*.py"))
    path.extend(glob.glob("day2/exer*.py"))
    path.extend(glob.glob("day3/exer*.py"))
    path.extend(glob.glob("day4/exer*.py"))
    path.extend(glob.glob("day5/exer*.py"))

    #すでに実行済みかをチェック
    with open(path[0], encoding="utf-8") as f:
        s = f.read()
    if s[:7] == '#dm2025':
        #初期化済み
        print("初期化は実行済みです。このフォルダにある init_key.txt が初期化キーです。")
        print("そちらの初期化キーを scombzより提出してください")
        exit()

    for p in path:
        with open(p, encoding="utf-8") as f:
            s = f.read()
        s1 = "#dm2025 " + str(hashval)
        s = s1 + s
        with open(p, 'w',  encoding="utf-8") as f:
            f.write(s)
    print("initialize success" + key)

    with open("init_key.txt", "w", encoding="utf-8") as f:
        f.write(key + "\n")
        f.write(hashval + "\n")
