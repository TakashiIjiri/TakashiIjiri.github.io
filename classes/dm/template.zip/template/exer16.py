#
#dm template
# これより上は編集しないこと

import numpy as np
import sys
import cv2

fname_in  = sys.argv[1]
d  = int(sys.argv[2])
sc = float(sys.argv[3])
ss = float(sys.argv[4])
fname_out = sys.argv[5]

#以下を編集 (2~3行で書けると思います)
