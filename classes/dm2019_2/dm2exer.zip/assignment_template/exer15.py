# -*- coding: utf-8 -*-
#  excer15.py
#  入力画像をグレースケール化し，Otsu法により二値化する
#
#  $python  exer15.py   fname_in.png  fname_out.png
#  fname_in.png  : 入力画像のファイル名
#  fname_out.txt : 出力画像のファイル名
#

import numpy as np
import sys
import cv2


# ヒストグラム数列から画素数、平均、分散を計算する関数（必用なら利用してください）
# valueは、[0,1,2,3,4,...,255]という数列です（ヒストグラムの横軸の画素値を表します）
# histoは、頻度が入った配列です
def calcPixnumMeanVari( histo, value ) :
    num  = np.sum(histo)
    mean = np.sum(histo * value) / num
    vari = np.sum(histo * ( (value - mean)**2) ) / num
    return num, mean, vari

fname_in  = sys.argv[1]
fname_out = sys.argv[2]

#画像を読み込み輝度画像へ変換
img = cv2.imread(fname_in)
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)



#---------------------------------------

#ここを編集

#TODO 1 ヒストグラムを計算
histo = np.zeros( 256, dtype = int )


# 2 ヒストグラムから全体の画素数・平均・分散を計算
value = np.arange(256)
num, mean, vari = calcPixnumMeanVari(histo, value)


#TODO 3 Otsu法により閾値threshを計算
#ヒント: スライスをうまく使うとコードが綺麗にかけます
#calcPixnumMeanVari(histo[a:b], value[a:b])　
#上のようにとすると [a,b)の範囲の平均値、分散値を計算できます．


thresh = 0


#画像の二値化（pythonでは以下の表記が可能(自分で書いてもらっても良いです)）
img[img >= thresh] = 255
img[img <  thresh] = 0
#---------------------------------------



cv2.imwrite( fname_out, img )
