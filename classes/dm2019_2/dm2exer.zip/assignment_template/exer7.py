# -*- coding: utf-8 -*-
#  exer7.py
#  template matchingを行い，最もマッチした場所に四角形を描画
#  四角形はテンプレートと同じサイズで，線幅2, 色(255,255,255)とする
#
#  $python   exer7.py   fname_in1.png  fname_in2.png  fname_out.png
#
#  fname_in1.png : ターゲット画像のファイル名
#  fname_in2.png : テンプレート画像のファイル名
#  fname_out.png : 出力画像のファイル名

import numpy as np
import sys
import cv2

fname_in1 = sys.argv[1]
fname_in2 = sys.argv[2]
fname_out = sys.argv[3]

#画像を読み込み輝度画像へ変換（SSDがオーバーフローしないようfloat64にキャスト）
target_img   = cv2.imread(fname_in1)
template_img = cv2.imread(fname_in2)
target_img   = cv2.cvtColor(target_img  , cv2.COLOR_RGB2GRAY)
template_img = cv2.cvtColor(template_img, cv2.COLOR_RGB2GRAY)


#--------------------------------------------

#ここを編集 cv2.matchTemplate関数を利用する
#TODO template matching
#TODO 最適な画素位置検索
#TODO 四角形描画

#--------------------------------------------


cv2.imwrite(fname_out, target_img)
