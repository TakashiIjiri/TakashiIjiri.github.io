# -*- coding: utf-8 -*-
#  exer12.py
#  入力画像を以下の手順でHough変換
#
# 課題11
# 1. 入力画像をグレースケール画像化
# 2. グレースケール画像の勾配強度画像を計算
#       勾配計算には右図のsobel filterを利用し
#       最大値で全体を除算し[0,1]に正規化する
# 3. 勾配強度画像を閾値により二値化（値0.4以上を前景に）
# 4. 前景画素の位置を利用し，以下の通りHough変換画像へ投票
#       Θの値域は[0,360]で，1画素の幅が1度分に対応
#       ρの値域は[0,A]で，1画素の幅が1画素分に対応（Aは画像の対角方向の長さ）
#       Hough変換画像には投票数（直線の本数）を登録し，最後に最大値を利用して[0,255]に正規化すること　
#
# ここから課題12
# 5. 投票結果を開票
#    投票数が 80 以上の (ρ,θ)の組を検索し，対応する直線を元画像に引く
#    直線は，色(255,0,0), 線幅1とする
#
# $python  exer12.py   fname_in.png  fname_out.png
#
#  fname_in.png  : 入力画像のファイル名
#  fname_out.png : 出力画像(Hough変換画像)のファイル名
#

import numpy as np
import math
import sys
import cv2

fname_in  = sys.argv[1]
fname_out = sys.argv[2]

#画像を読み込み輝度画像へ変換
img = cv2.imread(fname_in)
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

#勾配強度画像の計算
img_gradmag = np.zeros(img.shape, dtype = np.float64)
for y in range( 1, img.shape[0]-1 ) :
    for x in range( 1, img.shape[1]-1 ) :
        fx = -1.0 * img[y-1,x-1] + 0.0 * img[y-1,x ] + 1.0 * img[y-1,x+1] + \
             -2.0 * img[y  ,x-1] + 0.0 * img[y  ,x ] + 2.0 * img[y  ,x+1] + \
             -1.0 * img[y+1,x-1] + 0.0 * img[y+1,x ] + 1.0 * img[y+1,x+1]

        fy = -1.0 * img[y-1,x-1] - 2.0 * img[y-1,x ] - 1.0 * img[y-1,x+1] + \
              0.0 * img[y  ,x-1] + 0.0 * img[y  ,x ] + 0.0 * img[y  ,x+1] + \
              1.0 * img[y+1,x-1] + 2.0 * img[y+1,x ] + 1.0 * img[y+1,x+1]
        fx /= 4
        fy /= 4
        img_gradmag[y,x] = math.sqrt(fx*fx + fy*fy )

img_gradmag = img_gradmag / np.max(img_gradmag)

#hough変換
A = int( math.sqrt( img.shape[0] ** 2 + img.shape[1] ** 2) )
img_hough = np.zeros((A,360), float)

#-------------------------------------

#ここを編集

#TODO 1 投票（Hough変換画像を生成する）
#課題12を利用してOK



#TODO 2 開票（投票数が80以上の直線を描画）
# imgは一度グレースケールにしてしまったのでカラーの円を書き込めない
# 再読み込みすると良い
# img = cv2.imread(fname_in)


#-------------------------------------

cv2.imwrite( fname_out, np.uint8( img ) )
