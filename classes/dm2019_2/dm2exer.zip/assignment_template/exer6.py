# -*- coding: utf-8 -*-
#  exer6.py
#  template matchingを行い，最もマッチした場所に四角形を描画
#  四角形はテンプレートと同じサイズで，線幅2, 色(255,0,0)とする
#
#  $python  exer6.py   fname_in1.png  fname_in2.png  fname_out.png
#
#  fname_in1.png : ターゲット画像のファイル名
#  fname_in2.png : テンプレート画像のファイル名
#  fname_out.png : 出力画像のファイル名
#

import numpy as np
import sys
import cv2

fname_in1 = sys.argv[1]
fname_in2 = sys.argv[2]
fname_out = sys.argv[3]

#画像を読み込み輝度画像へ変換（SSDがオーバーフローしないようfloat64にキャスト）
target_img   = cv2.imread(fname_in1)
template_img = cv2.imread(fname_in2)
target_img   = np.float64( cv2.cvtColor(target_img  , cv2.COLOR_RGB2GRAY) )
template_img = np.float64( cv2.cvtColor(template_img, cv2.COLOR_RGB2GRAY) )

# image size
H, W = target_img  .shape[0], target_img  .shape[1]
h, w = template_img.shape[0], template_img.shape[1]


#-------------------------------------------
#以下を編集

#TODO1 SSDを計算

#TODO2 SSDが最小となる画素位置を取得

#TODO3 四角形を描く(対象画像は一度グレースケールにしてしまったので、もう一回読む)
target_img = cv2.imread(fname_in1)
#線幅2，線の色(255,0,0)
#左上の座標は(min_x, min_y),　右下の座標は(min_x + w, min_y + h)


#-------------------------------------------


#画像を出力
cv2.imwrite(fname_out, target_img)
