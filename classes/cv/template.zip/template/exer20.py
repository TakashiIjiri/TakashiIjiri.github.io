# cv 2025
# This is a template for programming assignments in Computer Vision.


# プログラム全体を書いてください
