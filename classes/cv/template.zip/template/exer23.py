#
# cv 2024 template
# これより上は編集しないこと
#
# テクスチャ合成
#
# python exer23.py sample.png R output.png
# sample.png : 入力ファイル名
# R          : パッチ半径
# output.png : 出力ファイル名


# プログラム全体を書いてください
