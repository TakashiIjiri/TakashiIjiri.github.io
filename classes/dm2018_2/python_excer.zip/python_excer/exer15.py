# -*- coding: utf-8 -*-
#  exer15.py
#  MNISTのトレーニングデータを読み，さらにラベル値の不明な画像を一枚読み込み，
#  SVMによりラベルの値を推定せよ, 推定結果はoutput.txtへ
#
#  $python exer15.py img.png output.txt
#
#  img.png    : 入力画像のファイル名(推測対象)
#  output.txt : 推定結果を出力するファイル
#

import numpy as np
import sys
import cv2
import gzip
from sklearn import svm


# ここを編集
# exer14.py等を利用してください
# svmに関連する部分は3行くらいになるはずです
