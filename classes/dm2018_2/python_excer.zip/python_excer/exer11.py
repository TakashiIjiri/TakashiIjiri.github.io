# -*- coding: utf-8 -*-
#  exer6.py
#  入力画像をグレースケール化し，そのヒストグラムを計算する
#
#  $python  exer11.py   fname_in.png  output.txt
#
#  fname_in.png : ターゲット画像のファイル名
#  output.txt   : 出力画像のファイル名

import numpy as np
import sys
import cv2

fname_in  = sys.argv[1]
fname_out = sys.argv[2]

#画像を読み込み輝度画像へ変換
img = cv2.imread(fname_in)
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)



#ここを編集
#ヒント : ファイルの各行の書き込みは
# fp.write(str(i) + " " + str(histo[i]) + "\n")
# こんな感じにするとよい
