# -*- coding: utf-8 -*-
# exer1.py
# 2枚の画像を輝度値画像に変換し，SSDを出力する
#
#  $python exer1.py img1.png img2.png out.txt
#
#  img1.png : 入力画像1のファイル名
#  img2.png : 入力画像2のファイル名
#  out.png  : SSD値を書き込むファイル名
#  2枚の入力画像のサイズは等しいものとする


import numpy as np
import sys
import cv2

#load image
fname_in1 = sys.argv[1]
fname_in2 = sys.argv[2]
fname_out = sys.argv[3]
img1 = cv2.imread(fname_in1)
img2 = cv2.imread(fname_in2)

#輝度画像へ変換（SSDがオーバーフローしないようfloat64にキャスト）
img1 = np.float64( cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY) )
img2 = np.float64( cv2.cvtColor(img2, cv2.COLOR_RGB2GRAY) )

if(img1.shape != img2.shape ) :
    exit(0)

#cals SSD
sum_squre_diff = 0




#ここを編集して，sum_squre_diffを計算




f = open(fname_out, "w")
f.write( str(sum_squre_diff) )
f.close()
