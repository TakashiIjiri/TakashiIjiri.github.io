# -*- coding: utf-8 -*-
#  exer2.py
#  template matchingを行い，SSD値を画像として出力する
#  SSD値は，最大値を用いて正規化する
#
#  $python   exer2.py   fname_in1.png  fname_in2.png  fname_out.png
#
#  fname_in1.png : ターゲット画像のファイル名
#  fname_in2.png : テンプレート画像のファイル名
#  fname_out.png : 出力画像のファイル名
#

import numpy as np
import sys
import cv2

fname_in1 = sys.argv[1]
fname_in2 = sys.argv[2]
fname_out = sys.argv[3]

#画像を読み込み輝度画像へ変換（SSDがオーバーフローしないようfloat64にキャスト）
target_img   = cv2.imread(fname_in1)
template_img = cv2.imread(fname_in2)
target_img   = np.float64( cv2.cvtColor(target_img  , cv2.COLOR_RGB2GRAY) )
template_img = np.float64( cv2.cvtColor(template_img, cv2.COLOR_RGB2GRAY) )

# image size
H, W = target_img  .shape[0], target_img  .shape[1]
h, w = template_img.shape[0], template_img.shape[1]
ssd_img = np.zeros( (H-h+1, W-w+1) )




#ここを編集し、ssd_imgの書く画素値を計算




#最大値を利用して正規化 （このコードのままだとゼロ割が起きるので注意）
maxv = np.max(ssd_img)
ssd_img = ssd_img / maxv * 255.0
cv2.imwrite( fname_out, np.uint8(ssd_img) )
