# -*- coding: utf-8 -*-
# exer16.py
# 種画像を見込み，数をtextファイル出力する
#
#  $python exer16.py img.png out.txt
#
#  img.png  : 入力画像のファイル名
#  out.png  : 種の数を書き込むファイル名


import numpy as np
import sys
import cv2

#load image
fname_in  = sys.argv[1]
fname_out = sys.argv[2]
img = cv2.imread(fname_in)




#種を数える TODOここを編集
#自由にアルゴリズムを考えてください
#出力が正しければアルゴリズムが洗練されてなくてもＯｋ

tane_no_kazu = 0





f = open(fname_out, "w")
f.write( str(tane_no_kazu) )
f.close()
