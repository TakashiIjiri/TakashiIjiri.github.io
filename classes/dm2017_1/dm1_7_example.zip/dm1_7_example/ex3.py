# -*- coding: utf-8 -*-
# ex3.py

#1D array 
A  = [1,3,5,7]
print("output1:", A )

N  = len(A)  #要素数
a2 = A[2]    #2番目の要素を参照 
A.append(4)  #後ろに"4"を挿入
a = A.pop(2) #2番目の要素をpop 
A.remove(4)  #値が4の最初の要素を削除
print( "output2", N, a, a2, A )

#2D array
A = [[1,2],[3,4],[5,6]]
print( "output3", A[0][1], A, len(A))

#tupple 
T = (1,2,3)
# T[1] = 2  #error tappleは変更不可
print("output4",T, T[1])
