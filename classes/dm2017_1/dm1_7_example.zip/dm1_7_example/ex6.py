# -*- coding: utf-8 -*-
# ex6.py
import numpy as np

A = np.array([1,2,3,4,5,6,7,8])

#Aの全要素をまわる
sum = 0
for p in A :
    print( p )
    sum += p
    tmp = 5

print(sum / A.shape[0])
print(tmp) #tmpを外から参照可能

#添え字を利用し要素を参照する
sum = 0
N   = A.shape[0]
for i in range(N):
    sum += A[i]
print(sum / A.shape[0])
