# -*- coding: utf-8 -*-
# ex13.py
import numpy as np
import cv2

#サイズ100x100の画像を作成
H   = 200
W   = 200
img = np.zeros( (H,W), np.uint8 )

#画素値代入(縦じま)
for y in range(H) : 
	for x in range(W) :
		if( x % 2==0) : 
			img[y,x] = x
		else :
			img[y,x] = 255

#矩形領域に一度で代入も可能        
img[50:60, 50:70] = 255

#display img
cv2.imshow("image", np.uint8( img) )
cv2.waitKey()