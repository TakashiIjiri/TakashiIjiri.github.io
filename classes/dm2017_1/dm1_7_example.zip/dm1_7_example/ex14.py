# -*- coding: utf-8 -*-
# ex14.py
import numpy as np
import cv2

#load image, convert to grayscale float
img = cv2.imread("img.png")
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
img = np.float64(img)

img_out = np.zeros_like( img )

for y in range( 1, img.shape[0]-1 ) : 
	for x in range( 1, img.shape[1]-1 ) : 
		img_out[y,x] = 128 #ここを編集
		#ヒント: img[y-1,x-1] これで自分の左上にアクセス

cv2.imshow( "output", np.uint8( img_out ) )
cv2.waitKey()
