# -*- coding: utf-8 -*-
# ex1.py

print("hello, world")
