# ex6.py
import numpy as np

A = np.array([1,2,3,4,5,6,7,8,9,10])

sum = 0
for p in A :
    print( p )
    sum += p
    tmp = 5

print(sum)
print(tmp) #tmpも参照可能

sum = 0
N   = A.shape[0]
for i in range(N):
    sum += A[i]
print(sum)
