# ex11.py
import numpy as np
import cv2

#load image
img = cv2.imread("img.png")
img = img.astype(np.float) 
H   = img.shape[0]
W   = img.shape[1]
img_gry = np.zeros( (H,W) )

for y in range(H) : 
    for x in range(W) :
        img_gry[y,x] = 128 #ここを編集
        
#display img
cv2.imshow("color image", np.uint8( img) )
cv2.imshow("gray  image", np.uint8( img_gry) )
cv2.waitKey()