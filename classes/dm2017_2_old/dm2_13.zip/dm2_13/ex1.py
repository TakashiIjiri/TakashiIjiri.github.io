# ex1.py

print("hello, world")
