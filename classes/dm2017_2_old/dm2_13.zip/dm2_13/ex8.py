# ex8.py
import numpy as np


def func(a,b) : 
    print("a is ", a)
    print("b is ", b)
    wa = a+b
    sa = a-b
    print("c is ", c) #外のcを参照できる
    return wa, sa

a = 1
b = 2
c = 5
sum, sub = func(1,2)

print( a,b, sum, sub)
