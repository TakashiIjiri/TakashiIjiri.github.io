# ex14.py
import numpy as np
import cv2

#load image, convert to grayscale float
img = cv2.imread("img.png")
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
img = np.float64(img)

img_out = np.zeros_like( img )

for y in range( 1, img.shape[0]-1 ):
	for x in range( 1, img.shape[1]-1 ):
		#ここを編集し平滑化フィルタを完成させる
		img_out[y,x] = 128

cv2.imshow( "output", np.uint8( img_out ) )
cv2.waitKey(0)
