# ex6.py
import numpy as np

a = [1,2,3]
b = a
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))


a = np.array([1,2,3])
b = a
b = np.copy(a)
b[1] = 10
print(a)
print(b)
print(id(a))
print(id(b))


a = 1 #aは [1]という値を持つ int オブジェクトを指す
b = a #bも aが参照していたint値オブジェクトを指す
print(a, id(a)) # aとbは同じものを参照
print(b, id(b)) # aとbは同じものを参照

b = 3 # ここが問題. 
# 数値はimmutable (不変)なので intオブジェクトに変更が起きない
# 代わりに新しいint値オブジェクトが生成されbはそれを指す

print(a, id(a)) # aとbは違うものを指す
print(b, id(b))
