# ex13slice.py
import numpy as np
import cv2

a1 = np.array([0,1,2,3,4,5,6,7,8,9])
a2 = np.array([2,2,2,2,2,2,2,2,2,2])

#2番目から5番目の要素を取り出す
print(a1[2:6])

#2番目から5番目に代入にする
a1[2:6] = a2[2:6]
print(a1[2:6])

#200x200の2D配列を作製
img1 = np.zeros( (200,200), np.uint8 )

#x=10～50, y=20～30の部分を取り出す
img2 = img1[20:31,10:51]
print(img2.shape)

#x=10～50, y=20～30の部分を白く塗る
img1[20:31,10:51] = 255

cv2.imshow("image", np.uint8( img1) )
cv2.waitKey(0)