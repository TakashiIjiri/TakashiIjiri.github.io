# -*- coding: utf-8 -*-
# exer2.pyの雛形

import sys

#1つの数値をコマンドライン引数から受け取る
N = int(sys.argv[1])

# !!このfor文の中を編集!!
#ヒント : if/elif/elseで簡単に書けます．
for i in range(1,N+1):
    print(i)

#発展 : （あまり綺麗ではないですが）内包表現を使うと1行で書けるので，
#pythonに興味がある人は調べてみてください
