# -*- coding: utf-8 -*-
# ex10.py
import numpy as np
import cv2

#load image
img = cv2.imread("img.png")
print( img.shape, type(img), img.dtype )

#draw rect and dots
cv2.line     (img,(100,100),(300,200), (0,255,255),2)
cv2.circle   (img,(100,100), 50,       (255,255,0),1)
cv2.rectangle(img,(100,100),(200,200), (255,0,255),1)
	
#display img
cv2.imshow("show image", img)
cv2.waitKey()

