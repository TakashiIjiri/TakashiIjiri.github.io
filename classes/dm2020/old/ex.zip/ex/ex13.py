# -*- coding: utf-8 -*-
# ex13.py
import numpy as np
import cv2

#サイズ200x200の画像を作成
N = 200
img = np.zeros( (N,N), np.uint8 )

#画素値代入(縦じま)
for y in range(N) : 
	for x in range(N) :
		if( x % 2==0) : 
			img[y,x] = x
		else :
			img[y,x] = 255

#矩形領域に一度で代入も可能(スライス表現)        
img[50:60, 50:70] = 255

#display img
cv2.imshow("image", np.uint8( img) )
cv2.waitKey()