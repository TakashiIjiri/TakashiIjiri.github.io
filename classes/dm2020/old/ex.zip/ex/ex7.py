# -*- coding: utf-8 -*-
# ex7.py
import numpy as np

A = np.array([1,2,3,4,5,6,7,8])

#Aの全要素の和をfor文で計算する
sum = 0
for p in A:
    print( p )
    sum += p

print(sum)

#range(N) を利用し N回繰り返しが可能  
sum = 0
N   = A.shape[0]
for i in range(N):
    print( A[i] )
    sum += A[i]

print(sum)

