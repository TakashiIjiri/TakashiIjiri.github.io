# -*- coding: utf-8 -*-
# ex9.py
import numpy as np

def func(a,b) : 
    print("a is ", a)
    print("b is ", b)
    print("c is ", c) #外のcを参照できる
    wa = a+b
    sa = a-b
    return wa, sa

a = 1
b = 2
c = 5
sum, sub = func(a,b)

print( a,b, sum, sub)
