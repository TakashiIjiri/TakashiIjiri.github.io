# -*- coding: utf-8 -*-
# ex5.py
import numpy as np

A = np.array([5,6,7,8])
B = np.array([1,2,3,4])
print(A.shape, A)
print(B.shape, B)

#要素ごとの演算(和差積商余べき)
C = A + B
D = A - B
E = A * B
F = A / B
G = A % B
H = A ** B
I = A + 3  #スカラーとの和

#2D 
A=np.array([[1,2,3],[4,5,6]])
B=np.array([[1,2,3],[4,5,6]])
C=A+B
print(C,C.shape)
