# -*- coding: utf-8 -*-
# ex3.py
import numpy as np
import cv2
import sys

img = cv2.imread( sys.argv[1] )
H   = img.shape[0]
W   = img.shape[1]

for y in range(H) : 
    for x in range(W) :
        img[y,x,2] = 128 #ここを編集
        
cv2.imshow("image", np.uint8( img) )
cv2.waitKey()

