# -*- coding: utf-8 -*-
import cv2
import numpy as np

CV_WAITKEY_CURSORKEY_RIGHT  = 2555904; #右カーソルID
CV_WAITKEY_CURSORKEY_LEFT   = 2424832; #左カーソルID


#手作業で位置合せをするツール
#"awsd"キーでマーカーの移動

if __name__ == '__main__':

    # read video
    cap   = cv2.VideoCapture( "video.mp4"  )
    ret, frame = cap.read()
    frame_num  = int( cap.get(cv2.CAP_PROP_FRAME_COUNT) )
    frame_H    = frame.shape[0]
    frame_W    = frame.shape[1]

    #マーカー位置を格納する配列を初期化
    markers = np.zeros( (frame_num,2) )
    for i in range(frame_num) : 
        markers[i][0] = frame_W // 2
        markers[i][1] = frame_H // 2
    
    frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2) )
    cv2.imshow( "video vis", frame_half)
    frame_I    = 0

    while (True) : 
        key = cv2.waitKey( 0 ) 
        
        if(   key == ord('q') ) :
            exit()
        elif( key == CV_WAITKEY_CURSORKEY_RIGHT ) :
            frame_I = min(frame_I+1, frame_num-1)
        elif( key == CV_WAITKEY_CURSORKEY_LEFT  ) :
            frame_I = max(frame_I-1, 0)
        elif( key == ord('a') ) : 
            markers[frame_I][0] -= 5
        elif( key == ord('w') ) : 
            markers[frame_I][1] += 5
        elif( key == ord('s') ) : 
            markers[frame_I][1] -= 5
        elif( key == ord('d') ) : 
            markers[frame_I][0] += 5
        elif( key == ord('x') ) : 
            for m in  markers : 
                print(m)

        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_I)
        ret, frame = cap.read()
        
        cx = int(markers[frame_I][0])
        cy = int(markers[frame_I][1])
        cv2.circle( frame, (cx,cy), 3, (255,255,0),2 ) 
        frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2))
        cv2.imshow("video vis", frame_half)

        print("current frame i = ", frame_I)
