# -*- coding: utf-8 -*-
# ex1.py
import numpy as np
import cv2
import sys

#load image
img = cv2.imread( sys.argv[1] )
print( img.shape, type(img), img.dtype )

#display img
cv2.imshow("show image", img)
cv2.waitKey()

#save image
cv2.imwrite("img_save.png", img);
