# -*- coding: utf-8 -*-
import cv2
import numpy as np

CV_WAITKEY_CURSORKEY_RIGHT  = 2555904; #右カーソルID
CV_WAITKEY_CURSORKEY_LEFT   = 2424832; #左カーソルID




def save_video( frame_W, frame_H, cap ) :    

    cap.set( cv2.CAP_PROP_POS_FRAMES, 0 )

    fourcc = cv2.VideoWriter_fourcc('m','p','4','v')
    out    = cv2.VideoWriter( 'video_out.mp4' , fourcc, 20.0, (frame_W, frame_H) )
    #fourcc = -1
    #out = cv2.VideoWriter( 'video.avi' , fourcc, 20.0, (frame.shape[1], frame.shape[0]))

    count = 0
    while( True ) : 
        ret, frame = cap.read()
        if ret == False :
            break
        
        count += 2
        cv2.circle(frame,(100+count,100), 50, (255,255,0),1)

        out.write( frame )

    out.release()






if __name__ == '__main__':

    # read video
    cap   = cv2.VideoCapture( "video.mp4"  )
    ret, frame = cap.read()

    frame_num  = int( cap.get(cv2.CAP_PROP_FRAME_COUNT) )
    frame_H    = frame.shape[0]
    frame_W    = frame.shape[1]

    frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2) )
    cv2.imshow( "video vis", frame_half)
    frame_I    = 0

    while (True) : 
        key = cv2.waitKey( 0 ) 
        
        if(   key == ord('q') ) :
            exit()
        elif( key == CV_WAITKEY_CURSORKEY_RIGHT ) :
            frame_I = min(frame_I+1, frame_num-1)

        elif( key == CV_WAITKEY_CURSORKEY_LEFT  ) :
            frame_I = max(frame_I-1, 0)
        
        elif( key == ord('s') ) : 
            save_video( frame_W, frame_H, cap )

        
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_I)
        ret, frame = cap.read()
        frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2))
        cv2.imshow("video vis", frame_half)

        print("current frame i = ", frame_I)
