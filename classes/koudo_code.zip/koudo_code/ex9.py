# -*- coding: utf-8 -*-
import cv2
import numpy as np

CV_WAITKEY_CURSORKEY_RIGHT  = 2555904; #右カーソルID
CV_WAITKEY_CURSORKEY_LEFT   = 2424832; #左カーソルID




# goodFeaturesToTrack  関数で角点を複数発見する --> pixels0
# calcOpticalFlowPyrLK 関数で連続するフレームのopticalflowを計算する
# opticalflowは，pixel0[i] の移動先が pixel1[i]に格納される
# rtには各pixel0[i]の対応が正しく計算できたかどうかのフラグが格納される
#参考: http://docs.opencv.org/2.4/modules/video/doc/motion_analysis_and_object_tracking.html
def opticalflow_corners( frame_W, frame_H, cap  ) : 

    cap.set( cv2.CAP_PROP_POS_FRAMES, 0 )
    ret, frame0 = cap.read()
    frame0_gray = cv2.cvtColor( frame0, cv2.COLOR_BGR2GRAY)

    # ShiTomasiコーナー検出
    feature_params = dict( maxCorners = 100, qualityLevel = 0.3, minDistance = 7, blockSize = 7 )
    pixels0        = cv2.goodFeaturesToTrack( frame0_gray, mask = None, **feature_params)

    #Lucas-Kanade法のパラメータ
    lk_params = dict( winSize  = (15,15), maxLevel = 2, criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
    
    lines = []
    count = 0
    while(1):
        ret,frame1 = cap.read()
        if ret == False : 
            break
        frame1_gray = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)

        # Optical flow計算(pixels1:移動先、st:) 
        pixels1, st, err = cv2.calcOpticalFlowPyrLK( frame0_gray, frame1_gray, pixels0, None, **lk_params)        
        old_pts = pixels0[st==1]
        new_pts = pixels1[st==1] #この表記法については bool index と fancy index

        lines.append([])
        for (a,b) in zip( old_pts, new_pts) :
            lines[-1].append( [ [a[0], a[1], b[0], b[1]] ] ) 
        
        frame0_gray = frame1_gray
        pixels0 = pixels1
        count += 1
        if( count > 100) : 
            break #時間がかかるので途中で止める
        print(count)

    #動画へ描画
    fourcc  = cv2.VideoWriter_fourcc('m','p','4','v')
    out     = cv2.VideoWriter( 'video_out.mp4' , fourcc, 20.0, (frame_W, frame_H) )

    count = 0
    cap.set( cv2.CAP_PROP_POS_FRAMES, 0 )
    while( True ) : 
        ret, frame = cap.read()
        if ret == False :
            break     

        for Ls in lines[count] : 
            for l in Ls : 
                cv2.line( frame, (l[0], l[1]), (l[2], l[3]), (255,0,0), 3)
        out.write( frame )
        count += 1
        if( count > 100) : 
            break #時間がかかるので途中で止める
    out.release()


    #画像へ描画
    cap.set( cv2.CAP_PROP_POS_FRAMES, 0 )
    ret, frame = cap.read()
    for c in range(100) : 
        for Ls in lines[c] : 
            for l in Ls : 
                cv2.line( frame, (l[0], l[1]), (l[2], l[3]), (255,0,0), 3)

    cv2.imwrite("test.png", frame )










if __name__ == '__main__':

    # read video
    cap   = cv2.VideoCapture( "video.mp4"  )
    ret, frame = cap.read()

    frame_num  = int( cap.get(cv2.CAP_PROP_FRAME_COUNT) )
    frame_H    = frame.shape[0]
    frame_W    = frame.shape[1]

    frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2) )
    cv2.imshow( "video vis", frame_half)
    frame_I    = 0

    while (True) : 
        key = cv2.waitKey( 0 ) 
        
        if(   key == ord('q') ) :
            exit()
        elif( key == CV_WAITKEY_CURSORKEY_RIGHT ) :
            frame_I = min(frame_I+1, frame_num-1)
        elif( key == CV_WAITKEY_CURSORKEY_LEFT  ) :
            frame_I = max(frame_I-1, 0)
        elif( key == ord('o') ) :
            opticalflow_corners(frame_W, frame_H, cap )

        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_I)
        ret, frame = cap.read()
        frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2))
        cv2.imshow("video vis", frame_half)

        print("current frame i = ", frame_I)
