# -*- coding: utf-8 -*-
import cv2
import numpy as np

CV_WAITKEY_CURSORKEY_RIGHT  = 2555904; #右カーソルID
CV_WAITKEY_CURSORKEY_LEFT   = 2424832; #左カーソルID


def color_threshold(frame_H, frame_W, cap ) :
    
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_I)
    
    while (1) : 
        ret, frame = cap.read()
        if ret == False :
            break

        # color threshold 水色である程度明るい色を
        c_min = np.array([70 , 100,  30], np.uint8)
        c_max = np.array([120, 255, 200], np.uint8)

        frame_hsv  = cv2.cvtColor( frame, cv2.COLOR_BGR2HSV)
        binary_img = cv2.inRange(frame_hsv, c_min, c_max           )
        binary_img = cv2.resize(binary_img, (frame_W // 2, frame_H // 2))

        #openningによるノイズ除去
        kernel = np.ones((3,3),np.uint8)
        binary_img = cv2.erode(binary_img, kernel,iterations = 1)
        binary_img = cv2.dilate(binary_img, kernel,iterations = 1)

        #重心の取得 (ここは遅い, もっと高速な方法はある)
        X = Y = S = 0
        for y in range( binary_img.shape[0]) :
            for x in range( binary_img.shape[1] ) : 
                if( binary_img[y,x] == 255) :
                    X += x
                    Y += y
                    S += 1
        X /= S
        Y /= S

        binary_img  = cv2.cvtColor( binary_img, cv2.COLOR_GRAY2BGR )
        cv2.circle( binary_img, (int(X),int(Y)), 3, (255,255,0), 4 )
        cv2.imshow("show binary image", binary_img)
        cv2.waitKey( 1 ) 





if __name__ == '__main__':

    # read video
    cap   = cv2.VideoCapture( "video.mp4"  )
    ret, frame = cap.read()
    frame_num  = int( cap.get(cv2.CAP_PROP_FRAME_COUNT) )
    frame_H    = frame.shape[0]
    frame_W    = frame.shape[1]

    #マーカー位置を格納する配列を初期化
    markers = np.zeros( (frame_num,2) )
    for i in range(frame_num) : 
        markers[i][0] = frame_W // 2
        markers[i][1] = frame_H // 2
    
    frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2) )
    cv2.imshow( "video vis", frame_half)
    frame_I    = 0

    while (True) : 
        key = cv2.waitKey( 0 ) 
        
        if(   key == ord('q') ) :
            exit()
        elif( key == CV_WAITKEY_CURSORKEY_RIGHT ) :
            frame_I = min(frame_I+1, frame_num-1)
        elif( key == CV_WAITKEY_CURSORKEY_LEFT  ) :
            frame_I = max(frame_I-1, 0)
        elif( key == ord('c') ) : 
            color_threshold(frame_H, frame_W, cap )

        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_I)
        ret, frame = cap.read()
        
        cx = int(markers[frame_I][0])
        cy = int(markers[frame_I][1])
        cv2.circle( frame, (cx,cy), 3, (255,255,0),2 ) 
        frame_half = cv2.resize(frame, (frame_W // 2, frame_H // 2))
        cv2.imshow("video vis", frame_half)

        print("current frame i = ", frame_I)
